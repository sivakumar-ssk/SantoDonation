package com.example.demo.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.model.Customer;

@FeignClient (name="${cust.name}",url="${cust.url}")
public interface CustomerClient {

	@GetMapping(value="/getallcustomers")
	public List<Customer> getcustomers();
}
