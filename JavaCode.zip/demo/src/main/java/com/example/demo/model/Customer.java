package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int custid;
	private String name;
	private int age;
	private long phoneno;
	
	public Customer(int custid, String name, int age, long phoneno) {
		super();
		this.custid = custid;
		this.name = name;
		this.age = age;
		this.phoneno = phoneno;
	}
	
	
	
	public Customer() {
		super();
	}



	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	
	
	
}
