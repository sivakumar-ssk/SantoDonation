package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.CustomerClient;
import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.model.Customer;
import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

import jakarta.transaction.Transactional;
@Service
public class ProductService {
	
	@Autowired
	CustomerClient customerClient;
	
	@Autowired
	ProductRepository productRepository;
	
	@Transactional
	public Product addproduct(Product product){
		return productRepository.save(product);
	}
	
	@Transactional
	public List<Product> getproducts(){
		return productRepository.findAll();
	}
	
	
	public Product updateproductbyId(int Id,String name, String brand, int rate, int ratings)throws ProductNotFoundException{
		Product product = productRepository.findById(Id).orElse(null);
		if(product == null) {
			throw new ProductNotFoundException("Product Was not found!");
		}
		product.setName(name);
		product.setBrand(brand);
		product.setRate(rate);
		product.setRatings(ratings);
		return productRepository.save(product);
	}
	
	@Transactional
	public Product giveratingsbyId(int Id, int ratings)throws ProductNotFoundException{
		Product product = productRepository.findById(Id).orElse(null);
		if(product == null) {
			throw new ProductNotFoundException("Product Was not found!");
		}
		product.setRatings(ratings);
		return productRepository.save(product);
	}
	
	@Transactional
	public void deleteproductbyId(int Id)throws ProductNotFoundException{
		if(productRepository.findById(Id)== null) {
			throw new ProductNotFoundException("Product Was not found!");
		}else {
		productRepository.deleteById(Id);
	}}
	
	@Transactional
	public List<Customer> getcustomers(){
		return customerClient.getcustomers();
	}
	
	
	
}
