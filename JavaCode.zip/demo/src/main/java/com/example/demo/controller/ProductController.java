package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.model.Customer;
import com.example.demo.model.Product;
import com.example.demo.service.ProductService;


@RequestMapping
@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;

	@PostMapping(value = "/addproduct")
	public Product addproduct(@RequestBody Product product){
		product = productService.addproduct(product);
		return product;
	}
	
	@GetMapping(value="/getallproducts")
	public List<Product> getproducts(){
		List<Product> list = productService.getproducts();
		return list;
	}
	
	@PutMapping(value="/updateproductbyid/{Id}")
	public Product updateproductbyId(@PathVariable("Id")int Id,@RequestParam String name, @RequestParam String brand, @RequestParam int rate, @RequestParam int ratings)throws ProductNotFoundException {
		Product product = productService.updateproductbyId(Id,name,brand,rate,ratings);
		return product;
	}
	
	@PutMapping(value="/giveratingsbyid/{Id}")
	public Product giveratingsbyId(@PathVariable("Id")int Id, @RequestParam int ratings)throws ProductNotFoundException {
		Product product = productService.giveratingsbyId(Id,ratings);
		return product;
	}
	
	@DeleteMapping(value="/deleteproductbyid/{Id}")
	public void deleteproductbyId(@PathVariable("Id") int Id)throws ProductNotFoundException{
		productService.deleteproductbyId(Id);
	}
	
	@GetMapping(value="/getallcustomers")
	public List<Customer> getcustomers(){
		List<Customer> list = productService.getcustomers();
		return list;
	}
	}
