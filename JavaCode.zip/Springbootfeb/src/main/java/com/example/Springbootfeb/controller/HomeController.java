package com.example.Springbootfeb.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class HomeController {

	@GetMapping("/homepage")
	public String greet(HttpServletRequest request) {
		
		return "Hello!!!!"+request.getSession().getId();
		
	}
}
