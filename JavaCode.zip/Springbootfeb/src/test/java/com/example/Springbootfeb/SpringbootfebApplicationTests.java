package com.example.Springbootfeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootfebApplicationTests {

	@Test
	void contextLoads() {
	}

}
