package com.jdbc.model;

public class Customers {
	
	private int cust_id;
	private String cust_name;
	private String phone_no;
	private int no_of_books;
	private String book_id;
	private String book_id_02;
	
	
	

	public Customers(int cust_id, String cust_name, String phone_no, int no_of_books, String book_id,
			String book_id_02) {
		super();
		this.cust_id = cust_id;
		this.cust_name = cust_name;
		this.phone_no = phone_no;
		this.no_of_books = no_of_books;
		this.book_id = book_id;
		this.book_id_02 = book_id_02;
	}



	public Customers(String cust_name, String phone_no, int no_of_books, String book_id, String book_id_02) {
		super();
		this.cust_name = cust_name;
		this.phone_no = phone_no;
		this.no_of_books = no_of_books;
		this.book_id = book_id;
		this.book_id_02=book_id_02;
	}



	public Customers(int cust_id) {
		super();
		this.cust_id = cust_id;
	}

	


	public Customers(String book_id, int cust_id) {
		super();
		this.book_id = book_id;
		this.cust_id = cust_id;
		
	}



	public Customers(int cust_id, String book_id) {
		// TODO Auto-generated constructor stub
		super();
		this.cust_id = cust_id;
		this.book_id = book_id;
	}



	public int getCust_id() {
		return cust_id;
	}



	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}



	public String getCust_name() {
		return cust_name;
	}



	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}



	public String getPhone_no() {
		return phone_no;
	}



	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}



	public int getNo_of_books() {
		return no_of_books;
	}



	public void setNo_of_books(int no_of_books) {
		this.no_of_books = no_of_books;
	}



	public String getBook_id() {
		return book_id;
	}



	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}



	public String getBook_id_02() {
		return book_id_02;
	}



	public void setBook_id_02(String book_id_02) {
		this.book_id_02 = book_id_02;
	}



	
	
	
}
