package com.jdbc.model;

public class Books {

	private String book_id;
	private String book_name;
	private boolean book_status;
	private String author_id;
	private int cust_id;
	
	public Books(String book_id, String book_name, boolean book_status, String author_id, int cust_id) {
		super();
		this.book_id = book_id;
		this.book_name = book_name;
		this.book_status = book_status;
		this.author_id = author_id;
		this.cust_id = cust_id;
	}

	

	public Books(String book_id) {
		super();
		this.book_id = book_id;
	}

	

	public Books(String book_id, int cust_id) {
		super();
		this.book_id = book_id;
		this.cust_id = cust_id;
	}

	public Books(int cust_id, String book_id) {
		super();
		this.cust_id = cust_id;
		this.book_id = book_id;
	}

	public Books(int cust_id, int cust_id1, String book_id) {
		super();
		this.cust_id = cust_id;
		this.cust_id = cust_id;
		this.book_id = book_id;
	}



	public String getBook_id() {
		return book_id;
	}

	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}

	public String getBook_name() {
		return book_name;
	}

	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	public boolean isBook_status() {
		return book_status;
	}

	public void setBook_status(boolean book_status) {
		this.book_status = book_status;
	}

	public String getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(String author_id) {
		this.author_id = author_id;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	
	
}
