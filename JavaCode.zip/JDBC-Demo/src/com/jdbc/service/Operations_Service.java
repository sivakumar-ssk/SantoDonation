package com.jdbc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.jdbc.db.ConnectionBuild;
import com.jdbc.model.Books;
import com.jdbc.model.Customers;
import com.jdbc.model.Employee;

public class Operations_Service {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static boolean insertNewCustomer(Customers customers){
		// TODO Auto-generated method stub
		try{
			Connection connection = ConnectionBuild.getConnection();
			String query = "insert into Customers(cust_name, phone_no, no_of_books, book_id, book_id_02) values (?, ?, ?, ?, ?);";
			 PreparedStatement preparedStatement = connection.prepareStatement(query);
             preparedStatement.setString(1, customers.getCust_name());
             preparedStatement.setString(2, customers.getPhone_no());
             preparedStatement.setInt(3, customers.getNo_of_books());
             preparedStatement.setString(4, customers.getBook_id());
             preparedStatement.setString(5, customers.getBook_id_02());
             
             int rows = preparedStatement.executeUpdate();
             if(rows>0) {
            	 System.out.println("The record is inserted");
             }
             else {
            	 System.out.println("Insertion failed..");
             }
             return true;
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}

	public static boolean deleteCustomer(Customers customers) {
		// TODO Auto-generated method stub
		try {
			Connection connection = ConnectionBuild.getConnection();
			String query = "update Books set cust_id=null, book_status=true where cust_id=?;";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, customers.getCust_id());
			
			int rows = preparedStatement.executeUpdate();
			int rows2=0;
			if(rows>0) {
				String query1 = "delete from Customers where cust_id=?;";
				PreparedStatement preparedStatement2 = connection.prepareStatement(query1);
				preparedStatement2.setInt(1, customers.getCust_id());
				
				rows2 = preparedStatement2.executeUpdate();
			}
			
			if(rows>0&&rows2>0) {
				System.out.println("The record is deleted");
			}
			else {
				System.out.println("deletion failed..");
			}
			
			return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static void getallBooks() {
		// TODO Auto-generated method stub
		try {
			Connection connection = ConnectionBuild.getConnection();
			String query = "select * from Books;";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("book_id"+" "+"book_name"+" "+"book_status"+" "+"author_id"+" "+"cust_id");
			while(rs.next()) {
				printBooks(new Books(rs.getString("book_id"),rs.getString("book_name"),rs.getBoolean("book_status"),
						rs.getString("author_id"),rs.getInt("cust_id")));
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
				
	}
	public static void printBooks(Books books) {
		System.out.println(books.getBook_id()+"  "+books.getBook_name()+"  "+books.isBook_status()+"  "+books.getAuthor_id()+"  "+books.getCust_id());
	}

	public static boolean takebook(int row, Books book, Customers customers) {
		// TODO Auto-generated method stub
		try {
			
			Connection connection = ConnectionBuild.getConnection();
			
			int rows=0,rows3=0,rows2=0,rows1=0;
			if(row==0) {
				String query = "update books as b join (select If(count(c.cust_id)=1,1,0) as res from customers as c left join books as b on b.cust_id=c.cust_id where c.cust_id =? and b.cust_id is null \r\n"
						+ "and b.book_id is null group by c.cust_id) as sup on 1=1 set cust_id = ?,book_status=false where b.book_id=? and sup.res=1;\r\n;";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, book.getCust_id());
				preparedStatement.setInt(2, book.getCust_id());
				preparedStatement.setString(3, book.getBook_id());
				
				rows = preparedStatement.executeUpdate();
				
				}
			else {
				String query5 = "update books set cust_id=?,book_status=false where book_id in (select book_id from (select cust_id,group_concat(book_id)from books group by cust_id having count(cust_id)<2 and cust_id =?)A)and cust_id is null and book_id=?;";
				PreparedStatement preparedStatement5 = connection.prepareStatement(query5);
				preparedStatement5.setInt(1, book.getCust_id());
				preparedStatement5.setInt(2, book.getCust_id());
				preparedStatement5.setString(3, book.getBook_id());
			
				rows3 = preparedStatement5.executeUpdate();
			}
			if(row==0) {
				String query1 = "update Customers set book_id =?, no_of_books=no_of_books+1 where cust_id=? and no_of_books=0;";
				PreparedStatement preparedStatement2 = connection.prepareStatement(query1);
				preparedStatement2.setString(1, customers.getBook_id());
				preparedStatement2.setInt(2, customers.getCust_id());
		
				rows1 = preparedStatement2.executeUpdate();
			}else {
				String query2 = "update Customers set book_id_02 =?, no_of_books=no_of_books+1 where cust_id=? and no_of_books=1 and book_id is not null;";
				PreparedStatement preparedStatement3 = connection.prepareStatement(query2);
				preparedStatement3.setString(1, customers.getBook_id());
				preparedStatement3.setInt(2, customers.getCust_id());
			
				rows2 = preparedStatement3.executeUpdate();
			}
			if(((rows>0)||(rows3>0))&&((rows1 >0)||(rows2>0))) {
				System.out.println("The book is taken successfully");
			}
			else {
				System.out.println("The customer cannot take this book..");
			}
			return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean returnbook(Books book, Customers customer) {
		// TODO Auto-generated method stub
		try {
			Connection connection = ConnectionBuild.getConnection();
			String query = "update Books set book_status=true, cust_id=null where book_id=?;";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, book.getBook_id());
			
			int rows = preparedStatement.executeUpdate();
			
			String query1 = "update Customers set no_of_books=no_of_books-1, book_id=null where cust_id=? and book_id=?;";
			PreparedStatement preparedStatement2 = connection.prepareStatement(query1);
			preparedStatement2.setInt(1, customer.getCust_id());
			preparedStatement2.setString(2, customer.getBook_id());
			
			int rows1 = preparedStatement2.executeUpdate();
			
			String query2 = "update Customers set no_of_books=no_of_books-1, book_id_02=null where cust_id=? and book_id_02=?;";
			PreparedStatement preparedStatement3 = connection.prepareStatement(query2);
			preparedStatement3.setInt(1, customer.getCust_id());
			preparedStatement3.setString(2, customer.getBook_id());
			
			int rows2 = preparedStatement3.executeUpdate();
			
			if((rows>0)&&((rows1>0)||(rows2>0))) {
				System.out.println("The book is returned");
			}
			else {
				System.out.println("The return is failed..");
			}
			return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean addbook(Books book) {
		// TODO Auto-generated method stub
		try {
			Connection connection = ConnectionBuild.getConnection();
			String query = "insert into Books (book_id,book_name,book_status,author_id,cust_id) values (?,?,?,?,?);";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, book.getBook_id());
			preparedStatement.setString(2, book.getBook_name());
			preparedStatement.setBoolean(3, book.isBook_status());
			preparedStatement.setString(4, book.getAuthor_id());
			preparedStatement.setInt(5, book.getCust_id());
			
			int rows = preparedStatement.executeUpdate();
			
			if(rows>0) {
				System.out.println("The book is added");
			}
			else {
				System.out.println("Book insertion is failed..");
			}
			return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static void getallCustomers() {
		// TODO Auto-generated method stub
		try {
			Connection connection = ConnectionBuild.getConnection();
			String query = "select * from Customers;";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("cust_id"+" "+"cust_name"+" "+"phone_no"+" "+"no_of_books"+" "+"book_id"+"book_id_02");
				while(rs.next()) {
					PrintCustomers(new Customers(rs.getInt("cust_id"),rs.getString("cust_name"),rs.getString("phone_no")
							,rs.getInt("no_of_books"),rs.getString("book_id"),rs.getString("book_id_02")));
				}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

	private static void PrintCustomers(Customers customers) {
		// TODO Auto-generated method stub
		System.out.println(customers.getCust_id()+"  "+customers.getCust_name()+"  "+customers.getPhone_no()+"  "+customers.getNo_of_books()+"  "+customers.getBook_id()+"  "
				+customers.getBook_id_02());
	}

	public static void getallEmployees() throws SQLException{
		// TODO Auto-generated method stub
		try {
			Connection connection = ConnectionBuild.getConnection();
			String query = "select * from employee;";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println("emp_id"+"  "+"emp_name");
			while(rs.next()) {
				PrintEmployees(new Employee(rs.getInt("emp_id"),rs.getString("emp_name")));
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

	private static void PrintEmployees(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println(employee.getEmp_id()+"  "+employee.getEmp_name());
	}

	public boolean deleteBooks(Books books) {
		// TODO Auto-generated method stub
		try {
			Connection connection = ConnectionBuild.getConnection();
			String query1 = "update Customers set no_of_books=no_of_books-1, book_id=null where book_id=? and book_id_02 is null;";
			PreparedStatement preparedStatement2 = connection.prepareStatement(query1);
			preparedStatement2.setString(1, books.getBook_id());
			int rows2 = preparedStatement2.executeUpdate();
			
			String query2 = "update Customers set no_of_books=no_of_books-1, book_id_02=null where book_id_02=? and book_id is not null;";
			PreparedStatement preparedStatement3 = connection.prepareStatement(query2);
			preparedStatement3.setString(1, books.getBook_id());
			int rows3 = preparedStatement3.executeUpdate();
			
			String query = "delete from Books where book_id = ?;";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, books.getBook_id());
			int rows = preparedStatement.executeUpdate();
			
			if(((rows3>0)||(rows2>0))&&(rows>0)) {
				System.out.println("The record is deleted");
			}
			else {
				System.out.println("Deletion is failed..");
			}
			return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	

	

}
