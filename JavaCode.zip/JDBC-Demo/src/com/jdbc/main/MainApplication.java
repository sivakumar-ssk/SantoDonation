package com.jdbc.main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

import com.jdbc.model.Books;
import com.jdbc.model.Customers;
import com.jdbc.service.Operations_Service;

public class MainApplication {

	@SuppressWarnings("static-access")
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Operations_Service operations_Service = new Operations_Service();
		
		try(Scanner scanner = new Scanner(System.in);){
			
			boolean isRun = true;
			
			while(isRun){ 
			
			System.out.println("Enter the operation you want to perform: ");
			System.out.println("1.Insert new Customer: ");
			System.out.println("2.Delete customer: ");
			System.out.println("3.Get all books: ");
			System.out.println("4.want to take book: ");
			System.out.println("5.want to return book: ");
			System.out.println("6.Adding a book: ");
			System.out.println("7.Delete a book: ");
			System.out.println("8.Get all customers: ");
			System.out.println("9.Get all employees: ");
			System.out.println("10.Exit");
			
			int choice = Integer.parseInt(scanner.nextLine());
			
			switch(choice) {
			case 1:
				System.out.println("Enter customer_name, phone_no, no_of_books, Book_id, Book_id_02: ");
				operations_Service.insertNewCustomer(new Customers(
						scanner.nextLine(),
						scanner.nextLine(),
						Integer.parseInt(scanner.nextLine()),
						scanner.nextLine(),
						scanner.nextLine())
						);
				break;
			
			case 2:
				System.out.println("Enter customer id: ");
				operations_Service.deleteCustomer(new Customers(
						Integer.parseInt(scanner.nextLine())
						));
				break;
				
			case 3:
				operations_Service.getallBooks();
				break;
			
			case 4:
				System.out.println("Enter no_of_books, cust_id, cust_id, book_id, book_id, cust_id: ");
				operations_Service.takebook(
									Integer.parseInt(scanner.nextLine()),
							new Books(
									Integer.parseInt(scanner.nextLine()),
									Integer.parseInt(scanner.nextLine()),
									scanner.nextLine()),
							new Customers(
								scanner.nextLine(),
								Integer.parseInt(scanner.nextLine())
								));
				break;
				
			case 5:
				System.out.println("Enter book_id, cust_id, book_id: ");
				operations_Service.returnbook(new Books(
						scanner.nextLine()),
						new Customers(
								Integer.parseInt(scanner.nextLine()),
								scanner.nextLine()
						));
				break;
				
			case 6:
				System.out.println("Enter book_id,book_name,book_status,author_id,cust_id: ");
				operations_Service.addbook(new Books(
						scanner.nextLine(),
						scanner.nextLine(),
						scanner.hasNext(),
						scanner.nextLine(),
						scanner.nextInt()
						));
				break;
			
			case 7:
				System.out.println("Enter a book_id: ");
				operations_Service.deleteBooks(new Books(scanner.nextLine()
						));
				break;
				
			case 8:
				operations_Service.getallCustomers();
				break;
				
			case 9:
				operations_Service.getallEmployees();
				break;
				
			case 10:
				isRun = false;
				break;
				
			default:
				System.out.println("Invalid Choice");
				break;	
				}
			}
		}
		catch(Exception e) {
			throw new RuntimeException("Something went wrong.."+e);
		}
	}
}
