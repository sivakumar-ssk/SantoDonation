package com.jdbc.db;
import java.sql.*;

public class ConnectionBuild {

	public static Connection getConnection(){
		Connection con = null;
		try {
			con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library","root","1234");
		}
		catch(Exception e){
			System.out.println("Connection Failed"+e);
		}
		if(con==null)
			System.out.println("Connection Failed");
		
		return con;
	}

}
