package com.example.cust.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.cust.model.Product;

@FeignClient (name="${prod.name}",url="${prod.url}")
public interface ProductClient {
	
	
	@GetMapping(value="/getallproducts")
	public List<Product> getproducts();
	
	@PutMapping(value="/giveratingsbyid/{Id}")
	public Product giveratingsbyId(@PathVariable("Id")int Id, @RequestParam int ratings); 
	
}
