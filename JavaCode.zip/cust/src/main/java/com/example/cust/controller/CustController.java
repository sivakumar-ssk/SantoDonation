package com.example.cust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.cust.entity.Customer;
import com.example.cust.exception.CustomerNotFoundException;
import com.example.cust.exception.ProductNotFoundException;
import com.example.cust.model.Product;
import com.example.cust.service.CustService;

@RestController
public class CustController {
	
	@Autowired
	CustService custService;
	
	@PostMapping(value = "/addcustomer")
	public Customer addcustomer(@RequestBody Customer customer){
		customer = custService.addcustomer(customer);
		return customer;
	}
	
	@GetMapping(value="/getallproducts")
	public List<Product> getproducts(){
		List<Product> list = custService.getproducts();
		return list;
	}
	

	@GetMapping(value="/getallcustomers")
	public List<Customer> getcustomers(){
		List<Customer> list = custService.getcustomers();
		return list;
	}
	
	@PutMapping(value="/updatecustomerbyid/{custid}")
	public Customer updatecustomerbyId(@PathVariable("custid")int custid,@RequestParam String name, @RequestParam int age, @RequestParam long phoneno)throws CustomerNotFoundException {
		Customer customer = custService.updatecustomerbyId(custid,name,age,phoneno);
		return customer;
	}
	
	@PutMapping(value="/giveratingsbyid/{Id}")
	public Product giveratingsbyId(@PathVariable("Id")int Id, @RequestParam int ratings)throws ProductNotFoundException {
		Product product = custService.giveratingsbyId(Id,ratings);
		return product;
	} 
	
}
