package com.example.cust.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.cust.exception.CustomerNotFoundException;
import com.example.cust.client.ProductClient;
import com.example.cust.entity.Customer;
import com.example.cust.exception.ProductNotFoundException;
import com.example.cust.model.Product;
import com.example.cust.repository.CustomerRepository;

import jakarta.transaction.Transactional;

@Service
public class CustService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	ProductClient productClient;
	
	@Transactional
	public Customer addcustomer(Customer customer){
		return customerRepository.save(customer);
	}
	
	@Transactional
	public Customer updatecustomerbyId(int custid,String name, int age, long phoneno)throws CustomerNotFoundException {
		Customer customer = customerRepository.findById(custid).orElse(null);
		if(customer == null) {
			throw new CustomerNotFoundException("Customer Was not found!");
		}
		customer.setName(name);
		customer.setAge(age);
		customer.setPhoneno(phoneno);
		return customerRepository.save(customer);
	}
	
	@Transactional
	public List<Product> getproducts(){
		return productClient.getproducts();
	}
	
	@Transactional
	public List<Customer> getcustomers(){
		return customerRepository.findAll();
	}
	
	@Transactional
	public Product giveratingsbyId(int Id, int ratings) {
		return productClient.giveratingsbyId(Id, ratings);
	}
	
}
