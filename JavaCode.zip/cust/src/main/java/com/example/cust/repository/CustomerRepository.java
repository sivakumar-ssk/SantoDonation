package com.example.cust.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.cust.entity.Customer;


@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{

}
