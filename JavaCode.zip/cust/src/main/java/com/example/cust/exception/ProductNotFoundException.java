package com.example.cust.exception;

public class ProductNotFoundException extends Exception  {
	public ProductNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}