package com.example.cust.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class Product {

		private String name;
		private String brand;
		@Id
		@GeneratedValue
		private int id;
		private int rate;
		private int ratings;
		
		public Product(String name, String brand, int id, int rate, int ratings) {
			super();
			this.name = name;
			this.brand = brand;
			this.id = id;
			this.rate = rate;
			this.ratings = ratings;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getBrand() {
			return brand;
		}

		public void setBrand(String brand) {
			this.brand = brand;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public int getRate() {
			return rate;
		}

		public void setRate(int rate) {
			this.rate = rate;
		}

		public int getRatings() {
			return ratings;
		}

		public void setRatings(int ratings) {
			this.ratings = ratings;
		}

		public Product() {
			super();
		}
		
		
		
		
}
