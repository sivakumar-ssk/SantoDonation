package com.spring.beans;

import org.springframework.beans.factory.annotation.Autowired;

public class Book {

	@Autowired
	Author author;
	
	private String BookId;
	private String BookName;
	private String author_id;
	
	public Book(String bookId, String bookName, String author_id) {
		super();
		BookId = bookId;
		BookName = bookName;
		this.author_id = author_id;
	}
	public Book() {
		// TODO Auto-generated constructor stub
	}
	public String getBookId() {
		return BookId;
	}
	public void setBookId(String bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookname(String bookName) {
		BookName = bookName;
	}
	public String getAuthor_id() {
		return author_id;
	}
	public void setAuthor_id(String author_id) {
		this.author_id = author_id;
	}
	@Override
	public String toString(){
		return "{Bookid= "+BookId+",Bookname= "+BookName+"}";
	}
	
}
