package com.spring.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

//import com.spring.beans.Author;
import com.spring.beans.Book;

public class BookService {

	@Autowired
	private JdbcTemplate jdbcTemplateObject;
	
	public BookService(JdbcTemplate jdbcTemplateObject) {
		super();
		this.jdbcTemplateObject = jdbcTemplateObject;
	}
	
	public List<Book> getAllBooks(){
		
		String query = "select * from Book;";
		List<Book> bookList = jdbcTemplateObject.query(query, new RowMapper<Book>() {
			public Book mapRow(ResultSet rs, int rowNum) throws SQLException {
				Book book1 = new Book();
				book1.setBookId(rs.getString(1));
				book1.setBookname(rs.getString(2));
				book1.setAuthor_id(rs.getString(3));
				return book1;
			}
		});
		return bookList; 
	}
	
	public void addBook(Book book) {
		
		String query = "insert into Book(BookId,BookName,author_id)values(?,?,?);";
	}
	
	/*public Book getBookById(int BookId) {
		
		String query = "select * from Book where BookId=?;";
		////Book book = jdbcTemplateObject.queryForObject(query, new RowMapper(), BookId){
			Book mapRow(ResultSet rs, int rowNum)throws SQLException {
				Book book = new Book();
				book.setBookId(rs.getString(1));
				book.setBookname(rs.getString(2));
				book.setAuthor_id(rs.getString(3));
				return book;
			}
		//});
		return book;*/
	
	public void updateBookById(Book book) {
		
		String query = ";";
	}
	public void deleteBookById(int BookId) {
		
		String query = "delete from Book where BookId=?;";
	}
}
