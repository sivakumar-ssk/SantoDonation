package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.beans.Author;
import com.spring.beans.Book;
import com.spring.service.BookService;


@Component
public class BookController {
	
	@Autowired
	BookService bookService;
	
	public List<Book> getAllBooks(){
		
		return bookService.getAllBooks();
	}
	
	public void addBook(Book book) {
		
		bookService.addBook(book);
	}

	/*public Book getBookById(int BookId) {
		
		return bookService.getBookById(BookId);
		
	}*/
	
	public void updateBookById(int BookId ,Book book) {
		
		bookService.updateBookById(book);
	}
	
	public void deleteBookById(int BookId) {
		
		bookService.deleteBookById(BookId);
	}
	

}
