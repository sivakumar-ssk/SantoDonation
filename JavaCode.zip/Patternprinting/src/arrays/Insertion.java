package arrays;

import java.util.Scanner;

public class Insertion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[5];
		Scanner sc = new Scanner(System.in);
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the value to be inserted: ");
		int d = sc.nextInt();
		System.out.println("Enter the position the value to be inserted: ");
		int pos = sc.nextInt();
		
		int[] arrnew = new int[arr.length+1];
		for(int i = 0; i < arrnew.length; i++) {
			if(i<pos) {
				arrnew[i]=arr[i];
			}
			else if(i==pos) {
				arrnew[i]=d;
			}
			else {
				arrnew[i]=arr[i-1];
			}
		}
		System.out.println("after inserted: ");
		for(int i = 0; i < arrnew.length; i++) {
			System.out.println(arrnew[i]);
		}
	}

}
