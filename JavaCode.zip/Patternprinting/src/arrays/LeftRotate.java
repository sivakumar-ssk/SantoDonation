package arrays;

import java.util.Scanner;

public class LeftRotate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of an array: ");
		int n = sc.nextInt();
		int[] arr = new int[n];
		System.out.println("Enter array elements: ");
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("enter the no.of times to be rotated: ");
		int d = sc.nextInt();
		
		for(int i = 0; i < d; i++) {
			int first = arr[0],j;
			for(j = 0; j < arr.length-1; j++) {
				arr[j] = arr[j+1];
			}
			arr[j]=first;
		}
		System.out.println("after rotation: ");
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
