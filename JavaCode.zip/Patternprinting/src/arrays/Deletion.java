package arrays;

import java.util.Scanner;

public class Deletion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[5];
		System.out.println("Enter array elements: ");
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter the element to be deleted: ");
		int d = sc.nextInt();
		int[] arrnew = new int[arr.length - 1];
		for(int i = 0; i < arrnew.length; i++) {
			if(arrnew[i]!=d) {
				arrnew[i]=arr[i];
			}
			if(arrnew[i]==d) {
				arrnew[i]=arr[i+1];
			}
		}
		System.out.println("After deletion: ");
		for(int i = 0; i < arrnew.length; i++) {
			System.out.println(arrnew[i]);
		}
	}

}
