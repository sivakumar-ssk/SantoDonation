package arrays;

import java.util.Scanner;

public class RightRotate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter array size: ");
		int n = sc.nextInt();
		int[] arr = new int[n];
		//int[] arrnew = new int[n];
		System.out.println("Enter array elements: ");
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("enter no.of times to be rotated: ");
		int d = sc.nextInt();
		
		for(int i = 0; i < d; i++) {
			int last = arr[arr.length-1],j;
			for(j = arr.length-1; j>0; j--) {
			//for(j=1;j<arr.length-1;j++) {
				arr[j]=arr[j-1];
			}
			arr[0]=last;
		}
		System.out.println("after right rotation: ");
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" " );
		}
	}

}
