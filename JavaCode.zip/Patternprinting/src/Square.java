
public class Square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int j;
		for(int i = 1; i <= n; i++) {

			for(j = 1; j <= n; j++) {
				System.out.print("* ");

		}
			System.out.println();
		}
	}

}
