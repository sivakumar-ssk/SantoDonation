package string;

import java.util.Scanner;

public class PrintEachWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		s = s+" ";
		String snew = "";
		for(int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if(c!=' ') {
				snew = snew + c;
			//	System.out.println(" ");
			}
			else{
				System.out.println(snew);
				snew = "";
			}
		}
		
		
		
	}

}
