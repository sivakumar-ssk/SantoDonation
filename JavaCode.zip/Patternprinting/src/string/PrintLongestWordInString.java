package string;

import java.util.Scanner;

public class PrintLongestWordInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String snew = "";
		String longestword = "";
		
		for(int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if(c != ' ') {
				snew = snew + c;	
			}
			else {
				snew = "";
			}
			if(longestword.length()<snew.length()) {
				longestword = snew;
			}
		}
		System.out.println(longestword);
		
	}

}
