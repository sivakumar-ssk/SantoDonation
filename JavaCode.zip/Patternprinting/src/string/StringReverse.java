package string;

import java.util.Scanner;

public class StringReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		String snew="";
		for(int i = 0; i < s.length();i++) {
			char c = s.charAt(i);
			snew = c + snew;
		}
		System.out.println("reversed: "+snew);
	}

}
