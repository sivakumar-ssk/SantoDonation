package string;

import java.util.Scanner;

public class FindDuplicateChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a string: ");
		String s = sc.nextLine();
		
		char[] c = s.toCharArray();
		for(int i = 0; i < c.length; i++) {
			for(int j = i+1; j < c.length; j++) {
				if(i != j && c[i] != c[j]) {
				//System.out.println(c[i]);
				//c = c.replace(c[i],'');
					//char[] d = c[i];
			}
		}}
			System.out.println("after removing duplicates:" +String.valueOf(c));
	

}}
