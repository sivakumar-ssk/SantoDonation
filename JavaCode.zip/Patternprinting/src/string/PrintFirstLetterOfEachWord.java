package string;

import java.util.Scanner;

public class PrintFirstLetterOfEachWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String[] split = s.split(" ");
		//StringBuilder newV = new StringBuilder();
		String newV = "";
		for (int i = 0; i < split.length; i++) {
			 newV = newV + split[i].substring(0, 1).toUpperCase() + split[i].substring(1) + " ";
		}
		System.out.println(newV);
	}
}
