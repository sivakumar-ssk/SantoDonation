package string;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {//
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the no to be find factorial: ");
		int n = sc.nextInt();
		double  fact = 1;
		for(int i = n; i >= 1; i--) {
			fact = fact * i;
		}
		System.out.println("the factorial of "+n +" is: "+fact );
	}

}
