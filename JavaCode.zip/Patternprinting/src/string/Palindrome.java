package string;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String rev="";
		//for(int i = 0; i < s.length();i++) {
			for(int i = s.length()-1; i>=0; i--) {
			char c = s.charAt(i);
			//rev = c + rev;
			rev = rev + c;
		}
		System.out.println("reversed: "+rev);
		if(rev.equalsIgnoreCase(s)) {
			System.out.println("The given string is palindrome");
		}
		else {
			System.out.println("The given string is not palindrome");
		}
	}

}
