package string;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Scanner;

public class demo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		//s = s + " ";
		String snew = "";
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c != ' ') {
				snew="";
				snew = c + snew;
				
				System.out.print(snew);
				
			}
			else if (c == ' ') {
				// System.out.println(snew);
				System.out.println("");
				snew = "";
			}
		}*/
		String originalInput = "test input";
		String encodedString = new String(Base64.getEncoder().encodeToString(originalInput.getBytes()));
		System.out.println(encodedString);
		String decodedString = new String(Base64.getDecoder().decode(encodedString), StandardCharsets.UTF_8);
		System.out.println(decodedString);
	}

}
