import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter no of rows: ");
		int row = sc.nextInt();
		System.out.println("Enter no.of.cols: ");
		int col = sc1.nextInt();
		
		for(int i = 1; i <= row; i++) {
			for(int j = 1; j<=col;j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}

}
