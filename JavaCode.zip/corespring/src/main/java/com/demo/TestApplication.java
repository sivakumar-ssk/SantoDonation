package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.Author;
import com.demo.beans.Book;

public class TestApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		ApplicationContext ac = new ClassPathXmlApplicationContext("config.xml");
		Author auth1 = (Author) ac.getBean("auth1");
		System.out.println("Author details: ");
		System.out.println(auth1.getAuthor_id());
		System.out.println(auth1.getAuthor_name());
		System.out.println(auth1.getPublisher_name());
		
		System.out.println("Author details: ");
		Author auth2 = (Author) ac.getBean("auth2");
		System.out.println(auth2.getAuthor_id());
		System.out.println(auth2.getAuthor_name());
		System.out.println(auth2.getPublisher_name());
		
		Book book1 = (Book) ac.getBean("book1");
		System.out.println("BookId  Book_name  Author_name  Publisher_name");
		System.out.println(book1.getBookId()+"      "+book1.getBookName()+ "   "+
		book1.getAuthor().getAuthor_name()+"       "+book1.getAuthor().getPublisher_name());
		
		Book book2 = (Book) ac.getBean("book2");
		System.out.println(book2.getBookId()+"      "+book2.getBookName()+ "   "+
		book2.getAuthor().getAuthor_name()+"       "+book2.getAuthor().getPublisher_name());
	
	}

}
