package com.demo.beans;

public class Book {
	
	private String BookId;
	private String BookName;
	private Author author;
	
	public String getBookId() {
		return BookId;
	}
	public void setBookId(String bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookname(String bookName) {
		BookName = bookName;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	
	@Override
	public String toString(){
		return "{Bookid= "+BookId+",Bookname= "+BookName+"}";
	}
	
}
