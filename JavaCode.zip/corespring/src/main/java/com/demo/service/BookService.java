package com.demo.service;

public class BookService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
