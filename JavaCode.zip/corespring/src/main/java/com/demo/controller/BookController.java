package com.demo.controller;

import java.util.List;

import org.springframework.stereotype.Component;

import com.demo.beans.Author;
import com.demo.beans.Book;

@Component
public class BookController {
	
	@SuppressWarnings("unchecked")
	public List<Book> getAllBooks(Book book){
		
		
		return (List<Book>) book;
		
	}

	public void saveAuthor(Author author) {
		
	}
	public void saveBook(Book book) {
		
	}
	//Read
	public Book getBookById(int Bookid) {
		
		return null;
		
	}
	//Update
	public void update(Book book) {
		
	}
	//Delete
	public void deleteBookById(int BookId) {
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
