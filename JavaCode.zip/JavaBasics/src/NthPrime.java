import java.util.Scanner;

public class NthPrime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number: ");
		int n = sc.nextInt();
		int c;
		prime(n);
		
	}
	
	public static void prime(int n) {
		int count = 0,num=1,i;
		while(count < n) {
			num = num + 1;
		for(i = 2; i <= num; i++) {
			if(num%i == 0) {
				break;
			}}
			if(i==num) {
			count = count+1;
			}
		
		}
		System.out.println(n +" th prime number is "+ num);
	}

}
