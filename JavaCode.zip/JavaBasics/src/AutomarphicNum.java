import java.util.Scanner;

public class AutomarphicNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number: ");
		int n = sc.nextInt();
		
		int sq = n*n;
		
		int flag = isautomorphic(n,sq);
		if(flag == 1) {
			System.out.println(n+" is not an automorphic");
		}
		else {
			System.out.println(n+" is an automorphic");
		}
	}
	public static int isautomorphic(int n, int sq) {
		int flag=0;
		while(n > 0) {
		if(n%10 != sq%10)
			flag = 1;
				
		n=n/10;
		sq=sq/10;
		
		//flag = 0;
		}
		return flag;
	}

}
