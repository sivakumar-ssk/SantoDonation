package streamss;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamFilterOperation {
	
	public static void main(String[] args) {
		
		//List of String
		//List of Integer
		//List of Character
		
		List<String> fruits = Arrays.asList("sri","siva","janani","","kabi","frank","siva"," ");
		List<Character> chars = Arrays.asList('b','X','e','z','L','3',' ');
		List<Integer> ints = Arrays.asList(11, 32, 49, 7, 23, 121);
		
		List<Character> c = chars.stream() 
				.filter(Character::isLetter)
				.collect(Collectors.toList());
		List<Character> c1 = chars.stream()
				.filter(Character::isWhitespace)
				.collect(Collectors.toList());
		List<Character> c2 = chars.stream()
				.filter(Character::isLowerCase)
				.collect(Collectors.toList());
		List<Character> c3 = chars.stream()
				.filter(Character::isUpperCase)
				.collect(Collectors.toList());
		List<Character> c4 = chars.stream()
				.filter(Character::isDigit)
				.collect(Collectors.toList());
	
		System.out.println("c: "+c);
		System.out.println("c1: "+c1);
		System.out.println("c2: "+c2);
		System.out.println("c3: "+c3);
		System.out.println("c4: "+c4);
		
		List<String> n = fruits.stream()
						.filter(s->s.startsWith("s"))
						.collect(Collectors.toList());
		List<String> n1 = fruits.stream()
						.filter(s->s.endsWith("i"))
						.collect(Collectors.toList());
		List<String> n2 = fruits.stream()
						.filter(s-> !s.isBlank()&& !s.isEmpty())
						.filter(s->s.charAt(0)=='f')
						.collect(Collectors.toList());
		List<String> n3 = fruits.stream()
						.filter(s->s.contains("an"))
						.collect(Collectors.toList());
		List<String> n4 = fruits.stream()
						.filter(s->!s.isBlank()&& !s.isEmpty())
						.collect(Collectors.toList());
		List<String> n5 = fruits.stream()
						.filter(s->!s.isEmpty())
						.collect(Collectors.toList());
		List<String> n6 = fruits.stream()
						.filter(s->s.length()>3)
						.collect(Collectors.toList());
		List<String> n7 = fruits.stream()
				.filter(s->s.equals("sri"))
				.collect(Collectors.toList());
		List<String> n8 = fruits.stream()
				.filter(s->s.equalsIgnoreCase(s))
				.collect(Collectors.toList());
		
		System.out.println(n);
		System.out.println(n1);
		System.out.println(n2);
		System.out.println(n3);
		System.out.println(n4);
		System.out.println(n5);
		System.out.println(n6);
		System.out.println(n7);
		System.out.println(n8);
		
		List<Integer> i = ints.stream()  //for integer hash code is exact same value
				.filter(s->s.hashCode()!=0)
				.collect(Collectors.toList());
		List<Integer> i1 = ints.stream()
				.filter(s->s%2==0)
				.collect(Collectors.toList());
		List<Integer> i2 = ints.stream()
				.filter(s->s%2!=0)
				.collect(Collectors.toList());
		List<Integer> i3 = ints.stream()
				.filter(s->Math.sqrt(s)<10)
				.collect(Collectors.toList());
	
		System.out.println(i);
		System.out.println(i1);
		System.out.println(i2);
		System.out.println("i3: "+i3);
		
	}

}
