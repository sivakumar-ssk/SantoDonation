package streamss;

public class Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {12,35,35,47,54,54,65};
		
		int j = 0;
		int temp;
		
		for(int i=1; i<arr.length; i++) {
			if(arr[i]!=arr[j]) {
				j++;
				temp = arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		for(int i=0;i<=j;i++) {
			System.out.println(arr[i]);
		}
	}
		

}
