package streamss;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
 class Product {
    private String name;
    private double price;
    private String category;

    public Product(String name, double price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getCategory() { return category; }

    @Override
    public String toString() {
        return name + " [" + category + "] - $" + price;
    }
}
public class streamOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = {1,2,3,4,5,6};
		char[] arr1 = {'b','x','e','z','l'};
		String[] arr = {"sri", "siva", "janani", "kabi", "frank", "siva"};
		Stream<String> name = Arrays.stream(arr);
		Map<Object, List<String>> groupby = name.collect(Collectors.groupingBy(s->s.charAt(0)));
		System.out.println(groupby);
								//.collect(Collectors.toList());
		Stream<String> names = Arrays.stream(arr);
		List<String> nams = names.collect(Collectors.toList());
		System.out.println(nams);
		//streams can't be reused
		List<String> uniquenames = Arrays.stream(arr)
				.distinct().collect(Collectors.toList());
		System.out.println(uniquenames);
		
		List<String> sortedNames = Arrays.stream(arr).sorted(Comparator.naturalOrder())
								   .collect(Collectors.toList());
		List<String> reverseSortedNames = Arrays.stream(arr).sorted(Comparator.reverseOrder())
				   .collect(Collectors.toList());
		List<String> sortedNamesByLength = Arrays.stream(arr).sorted(Comparator.comparing(String::length))
				   .collect(Collectors.toList());
		List<Character> liorder = IntStream.range(0, arr1.length).mapToObj(i->arr1[i])
				.sorted().collect(Collectors.toList());
		List<Character> lireverse = IntStream.range(0, arr1.length).mapToObj(i->arr1[i])
				.sorted(Comparator.reverseOrder())
				.collect(Collectors.toList());
		List<String> sortedNamesByLengthreversed = Arrays.stream(arr).sorted(Comparator.comparing(String::length).reversed())
				   .collect(Collectors.toList());
		
		System.out.println(sortedNames);
		System.out.println(reverseSortedNames);
		System.out.println(sortedNamesByLength);
		System.out.println(sortedNamesByLengthreversed);
		System.out.println(liorder);
		System.out.println(lireverse);
		
		IntStream strm = Arrays.stream(array);
		List<Integer> oddli = strm.boxed()
							  .filter(i -> i%2!=0)
							  .collect(Collectors.toList());
		
		System.out.println(oddli);
		List<Product> products = Arrays.asList(
			    new Product("Laptop", 85000, "Electronics"),
			    new Product("Chair", 3000, "Furniture"),
			    new Product("Phone", 60000, "Electronics"),
			    new Product("Table", 5000, "Furniture")
			);

			List<Product> electronics = products.stream()
	                .filter(p -> p.getCategory().equalsIgnoreCase("Electronics"))
	                .collect(Collectors.toList());
System.out.println(electronics);
			electronics.forEach(System.out::println);

			List<Product> product = products.stream()
	                .filter(p -> p.getName().equalsIgnoreCase("laptop"))
	                .collect(Collectors.toList());
			System.out.println(product);
	}

}
