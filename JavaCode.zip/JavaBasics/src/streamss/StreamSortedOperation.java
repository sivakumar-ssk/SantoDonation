package streamss;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StreamSortedOperation {

	public static void main(String[] args) {
		
		List<String> fruits = Arrays.asList("sri","siva","janani","kabi","frank","siva");
		List<Character> chars = Arrays.asList('b','X','e','z','L','3',' ');
		List<Integer> ints = Arrays.asList(11, 32, 49, 7, 23, 121);
		
		List<String> i = fruits.stream()
						.sorted()
						.collect(Collectors.toList());
		List<String> i1 = fruits.stream()
				.sorted(Comparator.reverseOrder())
				.collect(Collectors.toList());
		List<String> i2 = fruits.stream()
				.sorted(Comparator.comparing(String::length))
				.collect(Collectors.toList());
		List<String> i3 = fruits.stream()
				.sorted(Comparator.comparing(String::length).reversed())
				.collect(Collectors.toList());
		List<String> i4 = fruits.stream()
				.filter(s->!s.isBlank()&&!s.isEmpty())
				.sorted(Comparator.comparing(s->s.charAt(0)))
				.collect(Collectors.toList());
		List<String> i5 = fruits.stream()
				.filter(s->!s.isBlank()&&!s.isEmpty())
				.sorted(Comparator.comparing(s->s.charAt(s.length()-1)))
				.collect(Collectors.toList());
		
		fruits.stream().forEach(s->System.out.println(s+" -> "+s.length()));
			
		fruits.stream().forEach(s->System.out.println(s.charAt(0)+" -> "+s));
		
		System.out.println("i: "+i);
		System.out.println("i1: "+i1);
		System.out.println("i2: "+i2);
		System.out.println("i3: "+i3);
		System.out.println("i4: "+i4);
		System.out.println("i5: "+i5);
	}

}
