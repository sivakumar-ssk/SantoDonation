package streamss;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.stream.Collectors;

class Employee{
	private String name;
	private int age;
	private double salary;
	private String department;
	
	public Employee() {
		super();
	}
	
	public Employee(String name, int age, double salary, String department) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
		this.department = department;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", salary=" + salary + ", department=" + department + "]";
	}
	
	
}
public class GroupingbyStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> employee = Arrays.asList(
			new Employee("Srijaa M", 28, 75000.0, "IT"),
            new Employee("Arjun R", 32, 82000.0, "Finance"),
            new Employee("Priya K", 26, 68000.0, "HR"),
            new Employee("Siva", 30, 90000.0, "Marketing"),
            new Employee("Siva", 29, 72000.0, "IT"),
            new Employee("Karthik V", 35, 95000.0, "Sales"),
            new Employee("Meena L", 26, 70000.0, "Finance"),
            new Employee("Vikram T", 30, 88000.0, "Sales"),
            new Employee("Anjali D", 26, 66000.0, "HR"),
            new Employee("Ravi B", 32, 87000.0, "IT")

            );
				employee.stream()
						.filter(s->s.getAge()>26)
						.collect(Collectors.toList())
						.forEach(System.out::println);
				System.out.println("-----------------------------------------------------------------------------");
				System.out.println("-----------------------------------------------------------------------------");
				employee.stream()
						.map(s-> s.getDepartment().toUpperCase())
						.distinct()
						.collect(Collectors.toList())
						.forEach(System.out::println);
				System.out.println("-----------------------------------------------------------------------------");
				System.out.println("-----------------------------------------------------------------------------");
				employee.stream()
						.map(s-> new Employee(
								s.getName(),
								s.getAge(),
								s.getSalary(),
								s.getDepartment().toUpperCase()))
						.collect(Collectors.toList())
						.forEach(System.out::println);
		
		Double avgSalary = employee.stream().collect(Collectors.averagingDouble(s->s.getSalary()));
		Double sumofSalary = employee.stream().collect(Collectors.summingDouble(s->s.getSalary()));
		
		Map<Object, List<Employee>> e1 = employee.stream()
				.collect(Collectors.groupingBy(s->s.getDepartment()));
		
		Map<Object, List<Employee>> e2 = employee.stream()
				.collect(Collectors.groupingBy(s->s.getAge()));
		

Map<Integer, List<Employee>> groupedByAgeSorted = employee.stream()
    .collect(Collectors.groupingBy(Employee::getAge)) // Step 1: Group by age
    .entrySet()
    .stream()
    .sorted(Map.Entry.comparingByKey()) // Step 2: Sort by age
    .collect(Collectors.toMap(
        Map.Entry::getKey,
        Map.Entry::getValue,
        (i1, i2) -> i1,
        LinkedHashMap::new // Step 3: Preserve order
    ));
Map<Integer, List<Employee>> groupedByAgeSorted1 = employee.stream()
				.collect(Collectors.groupingBy( e->e.getAge(), TreeMap::new, 
						 Collectors.toList() ));
						
		List<String> fruits = Arrays.asList("apple","banana","blueberry","guava","cherry","plum","pineapple","apple");
		
		//Set<String> set = fruits.stream().collect(Collectors.toCollection(Collectors.toSet(), TreeSet::new));
		//System.out.println(set);
		
		Map<Character,List<String>> f = fruits.stream()
										.collect(Collectors.groupingBy(s->s.charAt(0)));
		
		for(Map.Entry<Character,List<String>> m: f.entrySet()) {
			System.out.println(m.getKey()+": "+m.getValue());
		}
		System.out.println(avgSalary);
		System.out.println(sumofSalary);
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------");
		for(Map.Entry<Object, List<Employee>> m : e1.entrySet()){
			System.out.println("Department: "+m.getKey()+" => "+m.getValue());
		}System.out.println("-----------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------");
		for(Map.Entry<Object, List<Employee>> m : e2.entrySet()){
			System.out.println("Age: "+m.getKey()+" => "+m.getValue());
		}
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------");
		for(Map.Entry<Integer, List<Employee>> m : groupedByAgeSorted.entrySet()){
			System.out.println("Age: "+m.getKey()+" => "+m.getValue());
		}
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------");
		for(Map.Entry<Integer, List<Employee>> m : groupedByAgeSorted1.entrySet()){
			System.out.println("Age: "+m.getKey()+" => "+m.getValue());
		}
		//System.out.println(f);
		Map<Object, Double> e5 = employee.stream()
				.collect(Collectors.groupingBy(s->s.getDepartment(),Collectors.averagingDouble(s->s.getSalary())));
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------");
		for(Entry<Object, Double> m : e5.entrySet()){
			System.out.println("Department: "+m.getKey()+" => Avg salary: "+m.getValue());
		}
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------");
		   Map<String,Double> e6 = employee.stream()
		   .collect(Collectors.groupingBy(s->s.getDepartment(), Collectors.summingDouble(s->s.getSalary())));
		 for(Map.Entry<String, Double> m: e6.entrySet()) {
			 System.out.println("Department: "+m.getKey()+"=> SumofSalary: "+m.getValue());
		 }
		 System.out.println("-----------------------------------------------------------------------------");
			System.out.println("-----------------------------------------------------------------------------");
			   Map<Integer,Long> e7 = employee.stream()
			   .collect(Collectors.groupingBy(s->s.getAge(),TreeMap::new, Collectors.counting()));

			 for(Entry<Integer, Long> m: e7.entrySet()) {
				 System.out.println("Age: "+m.getKey()+"=> count: "+m.getValue());
			 }
			System.out.println("-----------------------------------------------------------------------------");
				System.out.println("-----------------------------------------------------------------------------");
				   Map<Object, Optional<Employee>> e8 = employee.stream()
						   .collect(Collectors.groupingBy(s->s.getDepartment(),
						   Collectors.maxBy(Comparator.comparingDouble(e->e.getSalary()))));

				 for(Entry<Object, Optional<Employee>> m: e8.entrySet()) {
					 System.out.println("Department: "+m.getKey()+"=> Highest Salary: "+m.getValue());
				 }
				 
				 String s = "srijaa";
				 Map<Character, Long> m = s.chars().mapToObj(i->(char)i)
						 .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
				 System.out.println(m);
				 
				 Map<String, Long> m1 = fruits.stream()
						 .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
				 System.out.println(m1);
	}

}
