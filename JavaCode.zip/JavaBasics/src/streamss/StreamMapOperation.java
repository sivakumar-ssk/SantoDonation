package streamss;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamMapOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> fruits = Arrays.asList("sri","siva","janani","","kabi","frank","siva"," ");
		List<Character> chars = Arrays.asList('b','X','e','z','L','3',' ');
		List<Integer> ints = Arrays.asList(11, 32, 49, 7, 23, 121);
		
		List<Integer> i = ints.stream()  //for integer hash code is exact same value
				.map(s->s*s)
				.collect(Collectors.toList());
		List<Double> i1 = ints.stream()
				.map(s -> Math.sqrt(s))
				.collect(Collectors.toList());
		List<String> i2 = ints.stream()
				.map(s -> s % 2 == 0 ? "even" : "odd")
				.collect(Collectors.toList());
		List<Integer> i3 = ints.stream()
				.map(s -> s.toString().length()) 
				.collect(Collectors.toList());
	
		System.out.println(i);
		System.out.println(i1);
		System.out.println(i2);
		System.out.println("i3: "+i3);
	
		
		List<String> n = fruits.stream()
				.map(s->s.toUpperCase())
				.collect(Collectors.toList());
		List<String> n1 = fruits.stream()
				.map(String::toString)
				.collect(Collectors.toList());
		List<Boolean> n2 = fruits.stream()
				//.filter(s-> !s.isBlank()&& !s.isEmpty())
				.map(s->s.length()<=3)
				.collect(Collectors.toList());
		List<Boolean> n3 = fruits.stream()
				.filter(s-> !s.isBlank()&& !s.isEmpty())
				.map(s->s.length()<=3)
				.collect(Collectors.toList());
		List<Character> n4 = fruits.stream()
				.filter(s->!s.isBlank() && !s.isEmpty())
				.map(s->s.charAt(0))
				.collect(Collectors.toList());
		List<String> n5 = fruits.stream()
				.map(s-> new StringBuilder(s).reverse().toString())
				.collect(Collectors.toList());

		System.out.println("n: "+n);
		System.out.println("n1: "+n1);
		System.out.println("n2: "+n2);
		System.out.println("n3: "+n3);
		System.out.println("n4: "+n4);
		System.out.println("n5: "+n5);
	

	}

}
