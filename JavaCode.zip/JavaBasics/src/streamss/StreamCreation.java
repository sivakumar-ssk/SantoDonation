package streamss;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//List to stream creation

public class StreamCreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> names = List.of("sri", "siva", "janani", "kabi", "frank");
		List<String> names1 = List.of("manivannan","sumo");
		List<String> allnames = new ArrayList<>();
		allnames.addAll(names1);
		allnames.addAll(names);
		System.out.println(allnames);
		//names.addAll(names1);
		System.out.println(names);
		List<Integer> nums = Arrays.asList(5, 8, 3, 1);
		List<Character> chars = new ArrayList<>();
		chars.add('b');
		chars.add('x');
		chars.add('e');
		chars.add('z');
		chars.add('l');
		
		Stream<String> nms = names.stream();
		Stream<Integer> numbers = nums.stream();
		Stream<Character> charss = chars.stream();
		
		List<String> orderedNames = nms.sorted(Comparator.comparing(String::length).reversed())
									.collect(Collectors.toList());
		System.out.println(orderedNames);
	}

}
