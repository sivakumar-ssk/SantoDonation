package streamss;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

//array to stream creation 

public class StreamCreations {
	public static void main(String[] args) {	
		
		int[] arr = new int[5];
		//Character[] arr1 = {'b','x','e','z','l'};
		char[] arr1 = {'b','x','e','z','l'};
		String[] arr2 = {"sri", "siva", "janani", "kabi", "frank"};
		fill(arr);
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		Stream<String> nameStreams = Arrays.stream(arr2);
		//Stream<Character> charsstreams = Arrays.stream(arr1);
		List<Character> l = IntStream.range(0, arr1.length).mapToObj(i -> arr1[i]).collect(Collectors.toList());
		System.out.println(l);
		IntStream intStream = Arrays.stream(arr);
		List<Integer> li = intStream.boxed().collect(Collectors.toList());
		System.out.println(li);
	}
	
	static int[] fill(int[] arr){
		
		Scanner sc = new Scanner(System.in);
		for(int i=0; i<5; i++) {
			arr[i] = sc.nextInt();
		}
		return arr;
	}

}
