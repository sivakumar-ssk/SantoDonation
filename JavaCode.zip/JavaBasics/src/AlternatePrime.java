import java.util.Random;
import java.util.Scanner;

public class AlternatePrime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		//System.out.println("enter the numbers to be printed: ");
		//int n = sc.nextInt();
		int i,num=1,count = 0,flag;
		Random randomNumberGenerate = new Random();
		System.out.println(randomNumberGenerate.nextInt(99));
		/*while(count<n) {
			num = num + 1;
		for(i = 2; i < num; i++) {
			if(num%i == 0) {
				break;
			}}
			if(num == i) {
				count = count + 1;
			}
		}
		//System.out.println(num);
		}*/
	
	}
}
