import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Fun {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String s = sc.next();
		char[] arr = s.toCharArray();
		HashMap<Character,Integer> map = new HashMap<>();
		for(char c: arr) {
				map.put(c, map.getOrDefault(c, 0)+1);
			}
		for(Map.Entry<Character,Integer> m: map.entrySet()) {
			System.out.println(m.getKey() + ": "+m.getValue());
		}
		sc.close();
	}

}
