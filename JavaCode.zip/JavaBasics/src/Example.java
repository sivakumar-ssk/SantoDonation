
public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b = 0,res=0;
		try {
			//while (b!='\0'){
			res = a/b;
				
		//}
			b=5;
		}
		catch(ArithmeticException e) {
			System.out.println("arithmetic exception will occur "+ e.getMessage());
			b = 5;
			res = a/b;
			System.out.println("result "+res);
			//return b;
		}
		catch(RuntimeException e) {
			System.out.println("arithmetic exception will occur "+ e.getMessage());
		}
		finally {
			System.out.println("finally also executed ");
		}
	
	}

}
