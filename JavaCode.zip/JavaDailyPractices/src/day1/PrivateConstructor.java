package day1;


public class PrivateConstructor {
	int a;
	String s;
	private PrivateConstructor() {
		super();
		System.out.println("private constructor is called from same class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateConstructor obj = new PrivateConstructor();
		PrivateConstructor obj1 = new PrivateConstructor();
		obj.a=20;
		obj.s="sri";
		System.out.println(obj.a);
		System.out.println(obj.s);
		obj1.a=10;
		System.out.println(obj1.a);
	}

}
/*class Main{
	
	public static void main(String[] args) {
		//**cannot use private constructor from another class
		PrivateConstructor obj1 = new PrivateConstructor();
		//System.out.println(obj1);
	}
	}
*/	

