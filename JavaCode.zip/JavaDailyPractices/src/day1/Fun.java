package day1;

class Animal {
	String color = "white";

	public Animal() {
		// TODO Auto-generated constructor stub
		System.out.println("animal cons" +color);
	}

	void animal2() {
		System.out.println("1");
	}

	void color() {
		System.out.println("animal color" +color);
	}
}

class Dog extends Animal {
	String color = "black";

	public Dog() {
		// TODO Auto-generated constructor stub
		System.out.println("dog cons" +color);
	}
	@Override
	void animal2() {
		System.out.println("2");
	}
	void dog2() {
		System.out.println("rwe");
	}

	void color() {
		System.out.println(color);
//System.out.println(this.color);//prints color of Dog class  
//System.out.println(super.color);//prints color of Animal class  
	}
}

class Fun {
	public static void main(String args[]) {
Dog d=new Dog();
		Animal a = new Dog();
		Dog di=new Dog();
		a.color();
		a.animal2();
		d.dog2();
		System.out.println(a.getClass());
		if(a instanceof Animal) {
			System.out.println("animal");
		} else if(a instanceof Dog){
			System.out.println("dog");
		}
		else {
			System.out.println("null");
		}
	} 
}
