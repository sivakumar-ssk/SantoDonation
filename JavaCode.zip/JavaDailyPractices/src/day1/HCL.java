package day1;

import java.util.*;

class Result {
    public static String compressword(String word, int k) {
        StringBuilder sb = new StringBuilder();
        int count = 0; // consecutive count
        char[] arr = word.toCharArray();
        for (int i = 0; i < arr.length; i++) {
            char c = arr[i];

            if (sb.length() > 0 && sb.charAt(sb.length() - 1) == c) {
                count++;
            } else {
                count = 1;
            }

            sb.append(c);

            if (count == k) {
                sb.delete(sb.length() - k, sb.length()); // remove exactly k
                count = 0; // reset count after deletion
            }
        }

        return sb.toString();
    }
}

public class HCL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.nextLine();
        //int k = Integer.parseInt(sc.nextLine().trim());
        int k = sc.nextInt();
        System.out.println(Result.compressword(word, k));
    }
}

