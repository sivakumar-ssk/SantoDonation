package day1;

public class ObjectCreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ObjectCreation obj = new ObjectCreation();
		obj.show();
		//show();cannot call a non static method inside a static method, so object is 
		//created to access the non static method inside a static method
	}

	private void show() {
		// TODO Auto-generated method stub
		System.out.println("Object created");
	}

}
