package day1;

public class ObjectCreation1 {
	String sc = "Hello";
	int a;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ObjectCreation1 object = new ObjectCreation1();
		ObjectCreation1 obj2 = new ObjectCreation1();
		obj2.a=20;
		System.out.println(object.sc);
		System.out.println(obj2.a);
		System.out.println(object.a);
	}

}
