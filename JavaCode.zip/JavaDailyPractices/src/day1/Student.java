package day1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Students {

	int id;
	String name;
	
	Students(int id, String name){
		super();
		this.id= id;
		this.name=name;
	}
	
	@Override
	public String toString(){
		return "Student[ "+"Id: "+id+" Name: "+name+ " ]";
	}
}

public class Student{
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Students> li = new ArrayList<>();
		li.add(new Students(1,"sri"));
		li.add(new Students(2, "siva"));
		System.out.println(li);
		System.out.println();
	
	}

}
