package collections;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

class Employee{
	String name;
	int salary;
	
	public Employee(String name, int salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + "]";
	}
	
	
}
public class LinkedListObjectExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Employee> li = new LinkedList<>();
		li.add(0, new Employee("siva", 50000));
		li.add(1, new Employee("Janani", 40000));
		li.add(2, new Employee("srijaa", 30000));
		
		for(Employee e: li) {
		System.out.println(e);
		System.out.println();
		}
		
		HashMap<Integer, Employee> map = new HashMap<>();
		map.put(1, new Employee("siva", 50000));
		
		HashSet<Employee> set = new HashSet<>();
		set.add(new Employee("siva", 50000));
		
		System.out.println(li);
	}

}
