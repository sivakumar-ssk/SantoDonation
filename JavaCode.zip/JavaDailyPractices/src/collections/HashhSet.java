package collections;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class HashhSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		List<String> li = Arrays.asList("hi","hello","bye","anneyong","bye");
		HashSet<String> set = new HashSet<>();
		set.addAll(li);
		/*System.out.println("Enter the size of an set: ");
		int n = sc.nextInt();
		//String s;
		System.out.println("Enter the set: ");
		for(int i=0;i<n;i++) {
			set.add(sc.next());
		}*/
		System.out.println(set);
		List<String> strm = set.stream().sorted().collect(Collectors.toList());
		System.out.println(strm);
	}

}
