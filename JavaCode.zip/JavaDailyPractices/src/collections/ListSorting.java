package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class ListSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String[] arr = {"sri","siva","kabi"};
		List<String> l = new ArrayList<String>();
		List<String> li = new ArrayList<>();
		Collections.addAll(li, arr);
		String s;
		//System.out.println("enter the size of the list: ");
		//int n = sc.nextInt();
		/*System.out.println("Enter the list: ");
		for(int i=0;i<n;i++) {
			l.add(sc.next());
		}
		System.out.println(l);
		System.out.println();
		for(String i: l) {
			System.out.println(i);
		}*/
		l.add("hi");
		l.add("hello");
		l.add("sorry");
		l.add("bye");
		System.out.println(l);
		//l.remove(1);
		//l.clear();
		int n=0;
		System.out.println();
		if(l.contains("bye")){
			 n = l.indexOf("bye");
		}
		System.out.println(n);
		Collections.sort(l);
		System.out.println(l);
		l.sort(Comparator.reverseOrder());
		System.out.println(l);
		l.sort(Comparator.naturalOrder());
		System.out.println(l);
		l.sort(Comparator.comparing(String::length));
		System.out.println(l);
		l.sort(Comparator.comparing(String::length).reversed());
		System.out.println(l);
		l.sort(Comparator.comparing(String::length));
		System.out.println(l);
		
		
		
	}
}
