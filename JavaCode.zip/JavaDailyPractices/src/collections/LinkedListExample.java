package collections;

import java.util.LinkedList;

public class LinkedListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> l = new LinkedList<>();
		l.add(0, "sri");
		l.addFirst("siva");
		l.addLast("cutie pie");
		System.out.println(l);
		
		LinkedList<Integer> li = new LinkedList<>();
		li.add(0, 1);
		li.add(1, 2);
		li.add(2, 3);
		System.out.println(li);
		System.out.println(li.get(2));
		
		
		
	}

}
