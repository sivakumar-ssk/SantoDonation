package collections;

import java.util.HashSet;
import java.util.Scanner;

public class DeletioninHashSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		HashSet<String> set = new HashSet<>();
		System.out.println("Enter the size of an set: ");
		int n = sc.nextInt();
		//String s;
		System.out.println("Enter the set: ");
		for(int i=0;i<n;i++) {
			set.add(sc.next());
		}
		System.out.println(set);
		System.out.println("enter the element to be removed: ");
		String s = sc.next();
		//if(set.contains(s)) {
		//	set.remove(s);
		set.removeIf(str->str.contains(s));
		
	//}else {
			//System.out.println("the element is not found");
		//}
		System.out.println(set);
	
	}

}
