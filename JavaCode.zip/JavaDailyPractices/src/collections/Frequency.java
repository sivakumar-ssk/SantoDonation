package collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Frequency {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in); 
		String s = sc.nextLine();
		freq(s);
		
	}
	private static void freq(String s) {
		// TODO Auto-generated method stub
		HashMap<Character, Integer> frequency = new HashMap<>();
		for(int i=0; i<s.length(); i++) {
			char c = s.charAt(i);
			if(c==' ') {
				continue;
			}
			else {
			if(frequency.containsKey(c)) {
				frequency.put(c, frequency.get(c)+1);
			}
			else {
				frequency.put(c, 1);
			}
		   }
		 }
			for(Map.Entry<Character,Integer> m: frequency.entrySet() ) {
				System.out.println(m.getKey()+" "+m.getValue());
			}
	  }
   

}
