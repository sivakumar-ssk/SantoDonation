package collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class Listexample {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO Auto-generated method stub
		String[] s = {"hi","hello","anneyong","bye"};
		List<String> ri = new ArrayList<>();
		Collections.addAll(ri, s);
		System.out.println(ri);
		List<String> str = Arrays.asList("hi","hello","anneyong","bye");
		ri.addAll(str);
		System.out.println(ri);
		List<String> srt = Arrays.asList(s);
		System.out.println(str);
		System.out.println(srt);
		List<String> a = new ArrayList<String>();
		List<String> b = new ArrayList<String>();
		String l = "srijaa";
		b.add(0, l);
		System.out.println(b);
		for(String i: s) {
			a.add(i);
		}
		System.out.println();
		System.out.println(a);
		List<String> ab = new ArrayList<String>();
		for(String i: ab) {
			sc.next(i);
		}
		System.out.println(ab);
	/*	List<String> abc = new ArrayList<String>();
		System.out.println("enter the list size: ");
		int n = sc.nextInt();
		for(int i = 0; i<n; i++) {
			String input = sc.next();
			abc.add(input);
		}
		System.out.println(abc);
		List<Integer> abcd = new ArrayList<>();
		for(int i = 0; i<4; i++) {
			int num = sc.nextInt();
			abcd.add(num);
		}
		System.out.println(abcd);
		List<Integer> sri = new ArrayList<>();
		sri = List.of(1, 2, 3, 4, 5);
		System.out.println(sri);
		//sri.add(6);
		System.out.println(sri);
		List<Integer> i = new ArrayList<>();
		i.add(0);
		i.add(1);
		i.add(2);
		System.out.println(i);
		List<List<Integer>> j = Arrays.asList(i);
		List<String> k = Arrays.asList(s);
		System.out.println(k);
		System.out.println(j);*/
		System.out.println(a.get(0));
		a.set(0, "sri");
		System.out.println("a: "+a);
		//ListIterator<String> itr = a.listIterator();
			//while(itr.hasNext()) {
				//System.out.println(itr.nextIndex()+" "+itr.next()+" "+itr.next());
		ListIterator<String> itr = a.listIterator(1);
				System.out.println(itr.next());
				while(itr.hasNext()) {
				System.out.println("iteratornext"+itr.next());
				}
			//}
			Collections.sort(a);	
				//itr.so
			System.out.println(a);
			//while(itr.hasPrevious()) {
				//System.out.println(itr.previousIndex()+" "+itr.previous());
			//}
		//System.out.println();
			
	}

}
