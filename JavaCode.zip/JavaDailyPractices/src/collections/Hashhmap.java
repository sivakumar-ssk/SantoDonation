package collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Hashhmap {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of a map: ");
		int n = sc.nextInt();
		String s;
		//s.concat(t);
		HashMap<Integer,String> map = new HashMap<>();
		System.out.println("Enter the map: ");
		for(int i=1;i<=n;i++) {
			map.put(i,(sc.next()));
		}
		
		System.out.println(map);
		System.out.println("Size of the map is :"+map.size());
		map.replace(2, "hey", null);
		System.out.println(map.entrySet());
		System.out.println("Keys: "+map.keySet());
		System.out.println("Values: "+map.values());
		map.putIfAbsent(2, "hey");
		map.putIfAbsent(6, "siva");
		for(Map.Entry<Integer,String> m: map.entrySet()) {
		System.out.println(m.getKey()+" "+m.getValue());
		}
	}

}
