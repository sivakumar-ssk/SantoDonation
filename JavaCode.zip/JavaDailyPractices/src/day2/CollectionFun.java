package day2;
import java.util.*;
import java.util.Collection;

public class CollectionFun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Collection a;
		ArrayList<String> b = new ArrayList<>();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of an arraylist: ");
		int n = sc.nextInt();
		
		for(int i=0; i<n; i++) {
			b.add(sc.next());
		}
		
		System.out.println(b);
		b.add(4, "pattu");
		b.remove(3);
		b.set(1, "Hi");
		System.out.println(b);
		//for(int i: b) {
			//System.out.println(b);
		//}
		
	}

}
