package day2;

public class PrivateConstructor {

	static int a;
	private PrivateConstructor() {
		super();
		System.out.println("private constructor is called from same class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateConstructor obj = new PrivateConstructor();
		obj.a = 5;
		PrivateConstructor obj1 = new PrivateConstructor();
		obj1.a = 10;
		System.out.println(a);
	}

}
