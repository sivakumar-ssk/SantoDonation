package day2;

class Animall{
	
	String Animal_name = "pig";
	public void sound() {
		System.out.println("Oink Oink");
	}
	protected void sleep() {
		System.out.println("Zz");
	}
	
}
class Dog extends Animall{
	
	String name = "Dog";
	@Override
	public void sleep() {
		System.out.println(name+"sleeps");
	}
	
}
class Monkey extends Dog{
	
	String name = "Monkey";
	@Override
	public void sleep() {
		System.out.println(name + "sleeps");
	}
}
class MultiLevelInheritance{
	
	public static void main(String[] args) {
		
		Dog d = new Dog();
		d.sound();
		d.sleep();
		Animall a = new Animall();
		a.sleep();
		a.sound();
		Animall b = new Dog();
		b.sleep();
		Monkey m = new Monkey();
		m.sleep();
		
	}
}
