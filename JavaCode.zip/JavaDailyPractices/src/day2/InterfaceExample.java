package day2;

	interface example{
		 void animalSound();
		 void sleep();
		 default void show() {
			 System.out.println("first interface");
		 }
	}
	
	interface example1{
		void food();
	}

      class Animal implements example, example1{
	  // Abstract method (does not have a body)
    	  
    	// static int i = 5;
    	  
      @Override
	  public void animalSound() {
		  System.out.println("The animal says: grrr grrr");
	  }
      @Override
  	  public void sleep() {
  		// TODO Auto-generated method stub
    	  System.out.println("Zzz");
  		}
	@Override
	public void food() {
		// TODO Auto-generated method stub
		System.out.println("eats raw meat");
	}
	}

	class Pig implements example, example1 {
	  @Override
	  public void animalSound() {
	    // The body of animalSound() is provided here
	    System.out.println("The pig says: wee wee");
	  }
	  @Override
	  public void sleep() {
		   System.out.println("Zzz");
		  }
	@Override
	public void food() {
		// TODO Auto-generated method stub
		System.out.println("pig eats veggies");
	}
	}

	public class InterfaceExample {

		public static void main(String[] args) {
		//	example i = new Pig();
			//example in = new Animal();
		    Pig p = new Pig();
		    Animal a = new Animal();
		    //i.animalSound();
		    //i.sleep();
		    //in.animalSound();
		    //in.sleep();
		    a.animalSound();
		    a.sleep();
		   // p.sleep();
		    a.food();
		    a.show();
		    p.animalSound();
		    p.food();
		    p.show();
		    p.sleep();
		  }
}
