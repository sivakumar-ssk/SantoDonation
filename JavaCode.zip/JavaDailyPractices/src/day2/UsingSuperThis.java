package day2;

public class UsingSuperThis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Apple a = new Apple();
		a.color();
	}

}
class Fruits{
	
	String color = "multicolor";
}
class Apple extends Fruits{
	
	String color = "red";
	void color(){
		System.out.println(super.color);
		System.out.println(this.color);
	}
}
