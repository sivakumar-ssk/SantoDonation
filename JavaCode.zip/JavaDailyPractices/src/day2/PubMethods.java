package day2;
import day1.HCL.*;
public class PubMethods {
	
	public void show() {
		System.out.println("Hi! Sasi");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PubMethods obj = new PubMethods();
		obj.show();
		PubMethods obj1 = new PubMethods();
		//obj1.display();
		
	}

	

}
