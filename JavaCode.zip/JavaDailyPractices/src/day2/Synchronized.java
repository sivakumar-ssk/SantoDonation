package day2;

class Counter{
	
}

public class Synchronized {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
