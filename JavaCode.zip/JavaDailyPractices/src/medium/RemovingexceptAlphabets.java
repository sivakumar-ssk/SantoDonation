package medium;

import java.util.Scanner;

public class RemovingexceptAlphabets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		char[] arr = s.toCharArray();
		for(int i = 0; i < arr.length; i++) {
			if((arr[i]>='a'&&arr[i]<='z')||arr[i]>='A'&&arr[i]<='Z') {
				System.out.print(arr[i]);
			}
			else {
				continue;
			}
		}
	}

}
