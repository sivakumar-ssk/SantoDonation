package medium;

import java.util.Scanner;
import java.util.stream.Collectors;

public class RemoveDuplicatesfromString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		String result = s.chars().mapToObj(i->String.valueOf((char)i)).distinct()
				.collect(Collectors.joining());
		System.out.println(result);
	}

}
