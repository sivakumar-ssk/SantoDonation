package medium;

import java.util.Scanner;

public class ReplaceSubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a String: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		System.out.println("Enter a SubString: ");
		String t = sc.nextLine();
		System.out.println("String to be replaced: ");
		String r = sc.nextLine();
			String replaced = s.replace(t, r);
		System.out.println(replaced);
	}

}
