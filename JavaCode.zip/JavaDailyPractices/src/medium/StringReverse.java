package medium;

import java.util.Scanner;
import java.lang.StringBuilder;
public class StringReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		
		char[] arr = s.toCharArray();
		int startindex = 0;
		int endindex = arr.length-1;
			char temp;
			while(startindex<endindex) {
				temp = arr[startindex];
				arr[startindex] = arr[endindex];
				arr[endindex] = temp;
				startindex++;
				endindex--;
			}
			String rev = new String(arr);
			
		System.out.println(rev);
		
		String a = new String(s);
		String b = "SRIJAA";
		System.out.println("The entered string is: "+s);
		System.out.println("The copied string is: "+a);
		StringBuilder sb = new StringBuilder(s); 
		System.out.println("The reversed string is: "+sb.reverse().toString());
		System.out.println("The entered string length is: "+s.length());
		System.out.println(a.concat(b));
		System.out.println(b.compareToIgnoreCase(a));
	}

}
