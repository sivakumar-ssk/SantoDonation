package medium;

import java.util.Arrays;
import java.util.Scanner;
public class SortingAlphabetical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		char[] arr = s.toCharArray();
		//Arrays.sort(arr);
		for(int i = 0; i<arr.length;i++) {
			char temp = '\0';
			for(int j=i+1; j<arr.length; j++) {
				if(arr[j]<arr[i]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		
		for(char c: arr) {
			System.out.println(c+" ");
		}
		
	}

}
