package medium;

import java.util.Scanner;

public class CountVowelsinString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		char[] arr = s.toCharArray();
		int count=0;
		for(int i = 0; i < arr.length; i++) {
			if(arr[i]=='a'||arr[i]=='e'||arr[i]=='i'||arr[i]=='o'
					||arr[i]=='u'||arr[i]=='A'||arr[i]=='E'||arr[i]=='I'||arr[i]=='O'||arr[i]=='U') {
				count = count + 1;
			}
			else {
				continue;
			}
		}
		System.out.println("count of vowel is: "+count);
	}

}
