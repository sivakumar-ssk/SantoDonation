package medium;

import java.util.Scanner;

public class FindingDays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the month to be found: ");
		Scanner s = new Scanner(System.in);
		int month = s.nextInt();
		int year = s.nextInt();
		while(month<=7) {
		if(month==2) {
			if(year%4==0 && year%100!=0) {
				System.out.println("there are 29 days");
				break;
			}else {
				System.out.println("there are 28 days");
				break;
			}
		}
		if(month%2==0) {
			System.out.println("there are 30 days");
			break;
		}
		else {
			System.out.println("there are 31 days");
			break;
		}
	}
		while(month>7) {
			if(month%2==0) {
				System.out.println("there are 31 days");
				break;
			}
			else {
				System.out.println("there are 30 days");
				break;
			}
		}
	}
}
