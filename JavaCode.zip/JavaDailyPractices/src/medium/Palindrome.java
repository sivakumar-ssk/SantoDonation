package medium;

import java.util.Scanner;
import java.lang.StringBuilder;
public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Enter a string: ");
		//Scanner sc = new Scanner(System.in);
		//String s = sc.next();
		int a = 65;
		//char[] arr = String.valueOf(a).toCharArray();
		//for(int i=0;i<arr.length;i++) {
		//	System.out.print(arr[i]+" ");
		//}
		char c = (char)((int)a);
		System.out.println(c);
		/*StringBuilder sb = new StringBuilder(s);
		String sb1 = sb.reverse().toString();
		if(s.equalsIgnoreCase(sb1)) {
			System.out.println("Entered string is palindrome: "+s);
		}
		else {
			System.out.println("Entered string is not a palindrome: "+s);
		}
	}*/
	}
}
