package medium;

import java.util.Scanner;

public class NoofTimes5Occurs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number: ");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		//int times = count_in_range(n);
		int times = counts(n);
		System.out.println(times);
		
	}
	/*static int count_in_range(int n) {
		int count = 0 ;
		for (int i = 2; i <= n; i++)
			{
				count += counts(i);
			}
		return count;
	}*/
	static int counts(int n) {
		int count = 0;
		while(n!=0) {
			int rem = n%10;
			if(rem==5) {
				count++;
			}
			n=n/10;
		}
		return count;
	}

}
