package medium;

import java.util.Scanner;

public class CountCommonSubsequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter two strings: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String t = sc.nextLine();
		System.out.println("Enter the substring to be found: ");
		String sub = sc.next();
		if(s.contains(sub)) {
			System.out.println(sub+" -substring is found in string: "+s);
		}
		
		
	}

}
