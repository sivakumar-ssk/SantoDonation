package medium;

import java.util.Scanner;
import java.lang.StringBuilder;

public class Toggle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		//StringBuilder sb = new StringBuilder(s);
		char[] arr = s.toCharArray();
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>='a' && arr[i]<='z') {
				arr[i]=(char)((int)arr[i]-32);
			}
			else if(arr[i]>='A' && arr[i]<='Z') {
				arr[i]=(char)((int)arr[i]+32);
			}
			else {
				continue;
			}
		}
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]);
		}
	}

}
