package medium;

import java.util.HashSet;
import java.util.Scanner;

public class NonRepeatingCharsinString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		char[] arr = s.toCharArray();
//		char[] arr1 = new char[arr.length];
//		char[] arr2 = new char[arr.length];
//		int count, k = 0;
//		for (int i = 0; i < arr.length; i++) {
//			char d = arr[i];
//			if (!new String(arr1).contains(String.valueOf(d))) {
//				count = 1;
//				for (int j = i; j < arr.length; j++) {
//					if (arr[i] != arr[j] && i != j) {
//						arr1[k] = arr[i];
//						
//					}
//				}
//				k = k + 1;
//			}
//
//		}
//		for (int i = 0; i < k; i++) {
//			if (arr1[i] != '\0') {
//				System.out.print(arr1[i] + " ");
//			}
//		}
		//Set<String> set = new HashSet<>();
		
		for (int i = 0; i < arr.length; i++) {
			
		}
	}

}
