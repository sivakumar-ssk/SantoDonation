package medium;

import java.util.Scanner;

public class PrimeBetweenRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the numbers: ");
		Scanner s = new Scanner(System.in);
		int x = s.nextInt();
		int y = s.nextInt();
		while(x<y) {
			int flag = 0;
			for(int i=2; i<=x/2; ++i) {
				if(x%i==0) {
					flag = 1;
					break;
				}}
			if(flag==0) 
				System.out.print(x+" ");	
				x++;
			
			}
	}

}
