package medium;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter two strings: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String t = sc.nextLine();
		char[] arr = s.toCharArray();
		char[] arr1 = t.toCharArray();
		Arrays.sort(arr1);
		Arrays.sort(arr);
		
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]);
		}
		System.out.println();
		for(int i=0;i<arr1.length;i++) {
			System.out.print(arr1[i]);
		}
		System.out.println();
		if(Arrays.equals(arr, arr1)) {
			System.out.println("Two strings are anagram");
		}
		else {
			System.out.println("Two strings are not anagram");
		}
	}

}
