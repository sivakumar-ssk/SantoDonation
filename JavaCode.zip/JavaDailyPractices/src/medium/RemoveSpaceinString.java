package medium;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class RemoveSpaceinString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String sb = s.replaceAll(" ","");
		System.out.println(sb);
		
		String strm = Arrays.stream(s.split(" "))
				.collect(Collectors.joining());
		System.out.println(strm);
		/*char[] arr = s.toCharArray();
		char[] newarr = new char[arr.length];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==' ') {
				//System.out.print(arr[i]);
				//newarr[i]=arr[i+1];
				continue;
			}
			/*else if(arr[i]!=newarr[i]){
				newarr[i]=arr[i];
				//continue;
			}*/
			/*else {
				System.out.print(arr[i]);
			}
		}
		//for(int i=0;i<newarr.length;i++) {
			//System.out.print(newarr[i]);
		//}
	}*/
	}
}
