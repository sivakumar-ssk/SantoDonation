package medium;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FrequencyString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		char[] arr = s.toCharArray();
		Map<Character, Integer> occ = new HashMap<>();
		for (int i = 0; i < arr.length; i++) {
			if (!occ.keySet().contains(arr[i])) {
				int count = 1;
				for (int j = i + 1; j < arr.length; j++) {
					if (arr[i] == arr[j]) {
						count++;
					}

				}
				occ.put(arr[i], count);
			}

		}
		for(Entry e : occ.entrySet()) {
			System.out.println(e.getKey() + " = " + e.getValue());
		}
		//occ.entrySet().stream().forEach(System.out::println);
		Map<Character,Integer> map = new HashMap<>();
		for(char c: arr) {
			map.put(c, map.getOrDefault(c, 0)+1);
		}
		for(Map.Entry<Character,Integer> m: map.entrySet()) {
			System.out.println(m.getKey()+"->"+m.getValue());
		}
		
		Map<Character, Long> streams = s.chars().mapToObj(i->(char)i)
										 .collect(Collectors.groupingBy(Function.identity(),
												 Collectors.counting()));
		System.out.println(streams);
	}

}
