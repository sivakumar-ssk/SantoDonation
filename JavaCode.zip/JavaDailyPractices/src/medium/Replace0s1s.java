package medium;

import java.util.Scanner;

public class Replace0s1s {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number: ");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		char[] array = String.valueOf(n).toCharArray();
		for(int i = 0;i<array.length;i++) {
			if(array[i]=='0') {
				array[i]='1';
			}
			else {
				continue;
			}
		}
		for(int i = 0;i<array.length;i++) {
			System.out.print(array[i]);
		}
	}

}
