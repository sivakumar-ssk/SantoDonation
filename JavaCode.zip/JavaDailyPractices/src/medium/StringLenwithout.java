package medium;

import java.util.Scanner;

public class StringLenwithout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		System.out.println(s.length());
		char[] arr = s.toCharArray();
		int count=0;
		for(int i = 0; i < arr.length; i++) {
			if(arr[i]!='\0') {
				count = count + 1;
			}
			else if(arr[i]==' '){
				//break;
				continue;
			}
			else {
				break;
			}
		}
		System.out.println("String length is: "+count);
	}

}
