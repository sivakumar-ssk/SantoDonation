package medium;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CapitalizeFirstLetterEachWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		
		//System.out.println(s);
		char[] arr = s.toCharArray();
		
		String result = Arrays.stream(s.split(" "))
		.map(word->word.substring(0,1).toUpperCase()+word.substring(1))
		.collect(Collectors.joining(" "));
		
		System.out.println(result);
		
		if(arr[0]>='a'&&arr[0]<='z') {
			arr[0]=(char)((int)arr[0]-32);
			
		}
		for(int i = 1; i < arr.length; i++) {
			if(arr[i]==' ') {
				arr[i+1]=(char)((int)arr[i+1]-32);
			}
		}
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]);
		}
	}

}
