package faceprep;

import java.util.Scanner;

public class SumOfNatural {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number: ");
		Scanner n = new Scanner(System.in);
		int x = n.nextInt();
		int sum = 0;
		for(int i = 1; i <= x; i++) {
			sum = sum + i;
		}
		System.out.println("The sum of "+x+"natural numbers is: "+sum);
	}

}
