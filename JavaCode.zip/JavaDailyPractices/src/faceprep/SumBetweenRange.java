package faceprep;

import java.util.Scanner;

public class SumBetweenRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the numbers: ");
		Scanner s = new Scanner(System.in);
		int x = s.nextInt();
		int y = s.nextInt();
		int sum = 0;
		for(int i = x; i <= y;i++) {
			sum = sum + i;
		}
		System.out.println("the sum of "+x+" and "+y+" is: "+sum);
	}

}
