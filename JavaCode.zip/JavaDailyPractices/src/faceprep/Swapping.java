package faceprep;

import java.util.Scanner;

public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter two numbers: ");
		Scanner n = new Scanner(System.in);
		int x = n.nextInt();
		int y = n.nextInt();
		x = x*y;
		y = x/y;
		x = x/y;
		System.out.println("after two swapping: "+x+" "+y);
		
	}

}
