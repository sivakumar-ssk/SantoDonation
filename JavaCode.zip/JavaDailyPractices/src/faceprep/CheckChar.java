package faceprep;

import java.util.Scanner;

public class CheckChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a character: ");
		Scanner s = new Scanner(System.in);
		char c = s.next().charAt(0);
		switch(c) {
		case 'a':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'e':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'i':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'o':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'u':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'A':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'E':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'I':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'O':
			System.out.println("Entered character is a vowel:"+c);
			break;
		case 'U':
			System.out.println("Entered character is a vowel:"+c);
			break;
		default:
			System.out.println("Entered character is a consonant:"+c);
		}
	}

}
