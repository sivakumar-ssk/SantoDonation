package faceprep;

import java.util.Scanner;

public class Fact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number: ");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int result = factorial(n);
		System.out.println("The factorial of number "+n+" is: "+result);
	}
	static int factorial(int n) {
		int fact = 1;
		if(n==1) {
			return n;
		}
		else if(n==0) {
			return 1;
		}
		else {
			for(int i = 1;i <= n;i++) {
				fact = fact*i;
			}
				return fact;
		
	}
	}
}
