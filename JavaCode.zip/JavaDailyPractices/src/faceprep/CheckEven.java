package faceprep;

import java.util.Scanner;

public class CheckEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner n = new Scanner(System.in);
		int x = n.nextInt();
		if(x%2==0) {
			System.out.println("entered number is an even: "+x);
		}
		else {
			System.out.println("entered number is an odd: "+x);
		}

	}

}
