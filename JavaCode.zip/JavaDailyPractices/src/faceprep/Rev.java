package faceprep;

public class Rev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {3,4,5,2,7,8};
		for(int i=arr.length-1; i>=0;i--) {
			System.out.print(arr[i]+" ");
		}
	}

}
