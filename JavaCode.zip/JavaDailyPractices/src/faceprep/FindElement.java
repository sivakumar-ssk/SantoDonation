package faceprep;

import java.util.Scanner;

public class FindElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] arr = {3,4,5,2,7,8};
		int result = Search(arr);
		System.out.println("The element is in: "+result);
	}

	private static int Search(int[] arr) {
		// TODO Auto-generated method stub
		int d=5,index=0;
		for(int i = 0; i < arr.length; i++) {
			if(d==arr[i]) {
				index = i;
				break;
			}
		}
		return index;
	}

}
