package faceprep;

import java.util.Scanner;

public class CheckInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		char c = s.next().charAt(0);
		if((c >= 'a' && c <= 'z')){
			System.out.println("Entered character is a lowercase: "+c);
		}
		else if((c >= 'A' && c <= 'Z')){
			System.out.println("Entered character is a uppercase: "+c);
		}
		else {
			System.out.println("Entered character is a specialcase: "+c);
		}
	}

}
