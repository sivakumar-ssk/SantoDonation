package faceprep;

import java.util.Scanner;

public class Largest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the numbers: ");
		Scanner n = new Scanner(System.in);
		int x = n.nextInt();
		int y = n.nextInt();
		int z = n.nextInt();
		if(x>y && x>z) {
			System.out.println(x+" is the largest");
		}
		else if(y>x && y>z) {
			System.out.println(y+" is the largest");
		}
		else {
			System.out.println(z+" is the largest");
		}
	}

}
