package faceprep;

import java.util.Scanner;

public class Factors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number: ");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		System.out.println("Factors of a number "+n+" is: ");
		for(int i = 1; i <= n/2; i++) {
			if(n%i==0) {
				System.out.print(i+" ");
			}
		}
	}

}
