package faceprep;

import java.util.Scanner;

public class SumofDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number: ");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int x = n;
		int sum = 0,count = 0,rem,rev=0;
		while(x!=0) {
			rem=x%10;
			sum = sum + rem;
			rev = rem + (rev*10);
			x = x/10;
			count = count + 1;
		}
		System.out.println("sum of digits of "+n+" is: "+sum);
		System.out.println("no of digits of "+n+" is: "+count);
		System.out.println(" reverse of a number "+n+" is: "+rev);
	}

}
