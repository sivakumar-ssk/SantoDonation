package faceprep;

import java.util.Scanner;

public class Reverseanum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number: ");
		Scanner s = new Scanner(System.in);
		int x = s.nextInt();
		int z = x;
		int rem = 0, rev = 0,sum =0;
		while(x!=0) {
			rem = x%10;
			//sum = sum + rem;
			rev = (rev*10) + rem;
			x = x/10;
		}
		System.out.println("The reversed number is: "+rev);
	}

}
