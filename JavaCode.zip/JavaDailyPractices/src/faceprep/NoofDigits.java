package faceprep;

import java.util.Scanner;

public class NoofDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number: ");
		Scanner n = new Scanner(System.in);
		int x = n.nextInt();
		int count = 0;
		int z = x;
		while(x!=0) {
			x = x/10;
			count = count + 1;
		}
		System.out.println("The no.of.digits of "+z+": "+count);
	}

}
