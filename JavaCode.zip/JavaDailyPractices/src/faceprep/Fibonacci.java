package faceprep;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number: ");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		fibonacci(n);
		
	}

	static void fibonacci(int n) {
		int a=0,b=1;
		int sum = a+b;
		System.out.print(a+" "+b+" ");
		while(sum <= n) {
		System.out.print(sum+" ");
			a = b;
			b = sum;
			sum = a + b;

		}
	}
}
