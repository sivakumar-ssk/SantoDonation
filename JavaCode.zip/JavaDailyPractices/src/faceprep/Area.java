package faceprep;

import java.util.Scanner;
import java.lang.Math;

public class Area {
	
	//Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner n = new Scanner(System.in);
		int r = n.nextInt();
		double area = 3.14*(Math.pow(r, 2));
		System.out.println("area of circle: "+area);
	}

}
