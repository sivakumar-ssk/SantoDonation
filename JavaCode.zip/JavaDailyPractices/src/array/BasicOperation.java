package array;

import java.util.Scanner;

public class BasicOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the size of an array: ");
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr = new int[n];
		int[] arr1 = new int[n];
		System.out.println("Enter the array: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
