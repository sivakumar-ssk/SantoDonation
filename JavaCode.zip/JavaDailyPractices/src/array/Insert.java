package array;

import java.util.Arrays;
import java.util.Scanner;

public class Insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the array size: ");
		int size = s.nextInt();
		int arr[];
		arr=new int[size];
		int newarr[] = new int[size+1];
		System.out.println("Enter the array: ");
		for(int i=0;i<size;i++) {
			arr[i]=s.nextInt();
		}
		System.out.println("Enter the element to be inserted: ");
		int d = s.nextInt();
		System.out.println("Enter the position to be inserted: ");
		int pos = s.nextInt();
		for(int i = 0; i < newarr.length; i++) {
			//System.out.print(newarr[i+1]+" ");
			if(i==pos) {
				newarr[i]=d;
			}
			else if(i<pos) {
				newarr[i]=arr[i];
			}
			else if(i>pos) {
				newarr[i]=arr[i-1];
			}
			
	
		}
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i]+" ");
		}
		System.out.println();
		Arrays.sort(newarr);
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i]+" ");
		}
			}


}
