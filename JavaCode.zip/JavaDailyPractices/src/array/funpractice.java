package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class funpractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.nextLine();
//		char[] arr=;
//			    List<char[]> list = Arrays.asList(str.toCharArray());
//			    l=Arrays.asList(arr);
//			    for(int i=0;i<str.length(); i++){
//			      l[str.charAt(i)]++;
//			    }
//			    for(int i=0; i<l.length();i++){
//			      if(l[i]==1){
//			        System.out.print((char)i," ");
//			    }
//			    }
//			  }
		Map<Character, Integer> map = new HashMap<>();
		for(int i=0;i<str.length();i++) {
			Character c = str.charAt(i);
			map.put(c, map.getOrDefault(c, 0)+1);
		}
		System.out.println(map);
		for (Character c : map.keySet()) {
			if(map.get(c)==1) {
				System.out.println(c);
			}
		}	
	}

}
