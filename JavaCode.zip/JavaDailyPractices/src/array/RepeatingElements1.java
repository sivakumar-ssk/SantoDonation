package array;

import java.util.Scanner;

public class RepeatingElements1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array size: ");
		int n = sc.nextInt();
		int[] arr = new int[n];
		System.out.println("Enter the array elements: ");
		for(int i=0; i<arr.length; i++) {
			arr[i]=sc.nextInt();
		}
		
		int[] newarr=new int[n];
		int index=0;
		for(int i=0; i<arr.length; i++) {
			int flag=0;
			for(int j=0; j<i; j++) {
				if(arr[j]==arr[i] && i!=j) {
					flag=1;
					System.out.println(arr[j]);
					break;
				}
			}
		}
				/*if(flag==0) {
					newarr[index]=arr[i];
					index++;
				}
		
	}
		System.out.println("The repeating elements are: ");
		for(int i: newarr) {
			System.out.print(i+" ");
		}*/
	}
}
