package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ListSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the list size: ");
		int n = sc.nextInt();
		ArrayList<Integer> a = new ArrayList<>();
		for(int i=0;i<n;i++) {
			a.add(sc.nextInt());
		}
		Object[] arr = a.toArray();
		Arrays.sort(arr);
		
	}

}
