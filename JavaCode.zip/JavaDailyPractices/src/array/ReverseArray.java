package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array size: ");
		int n = sc.nextInt();
		int arr[];
		arr=new int[n];
		int newarr[]=new int[arr.length];
		System.out.println("Enter the array elements: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("reversed array: ");
		int j = arr.length-1;
		for(int i=0;i<arr.length;i++) {
			newarr[i]=arr[j];
			j--;
		}
		for(int i=0;i<newarr.length;i++) {
			System.out.print(newarr[i]+" ");
		}
		//List<int[]> c = new ArrayList<>();
		//c = Arrays.asList(arr);
		int[] array = {12,21,35,35,45,54,54,65};
		int startindex = 0,temp;
		int endindex = array.length-1;
		while(startindex<endindex) {
			temp = array[startindex];
			array[startindex] = array[endindex];
			array[endindex] = temp;
			startindex++;
			endindex--;
		}
		for(int i: array) {
			System.out.print(i+" ");
		}
	}

}
