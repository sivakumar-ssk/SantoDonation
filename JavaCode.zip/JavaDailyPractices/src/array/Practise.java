package array;

import java.util.Scanner;

public class Practise {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number: ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if(n%2==0) {
			System.out.println("Entered number is an even number: "+n);
		}
		else {
			System.out.println("Entered number is an odd number: "+n);
		}
		
	}

}
