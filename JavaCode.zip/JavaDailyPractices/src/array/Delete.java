package array;

import java.util.Scanner;

public class Delete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the array size: ");
		int size = s.nextInt();
		int arr[];
		arr=new int[size];
		int newarr[] = new int[size-1];
		System.out.println("Enter the array: ");
		for(int i=0;i<size;i++) {
			arr[i]=s.nextInt();
		}
		System.out.println("Enter the element to be deleted: ");
		int d = s.nextInt();
		int pos = 0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==d) {
				pos=i;
				break;
			}
		}
		System.out.println(pos);
		for(int i=0;i<newarr.length;i++) {
			if(i<pos) {
				newarr[i]=arr[i];
			}
			else if(i==pos||i>pos) {
				newarr[i]=arr[i+1];
			}
			
		}
		for(int i:newarr) {
			System.out.print(i+" ");
		}
	}

}
