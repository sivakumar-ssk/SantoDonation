package array;

import java.util.Arrays;
import java.util.Scanner;

public class Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size of an array: ");
		int n = sc.nextInt();
		
		int[] arr= new int[n];
		System.out.println("enter the array: ");
		for(int i=0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		int[] newarr=new int[n];
		for(int i=0; i<arr.length; i++) {
			int rem=0,rev=0;
			int temp=arr[i];
			while(temp!=0) {
				rem = temp%10;
				rev = (rev*10)+rem;
				temp=temp/10;
			int j = 0;
			if(rev==arr[i]) {
				newarr[j]=arr[i];
				j++;
			}
			}
		}
		for(int i: newarr) {
			System.out.print(i+" ");
		}
		System.out.println(Arrays.stream(newarr).max());
	}
}
