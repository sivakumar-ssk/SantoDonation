package array;

import java.util.Scanner;

public class SecondSmallest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size: ");
		int n = sc.nextInt();
		int arr[];
		arr=new int[n];
		System.out.println("Enter the elements: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		int smallest=arr[0];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]<smallest) {
				smallest=arr[i];
			}
		}
		int secondsmallest = arr[0];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==smallest) {
				continue;
			}
			else if(arr[i]<secondsmallest) {
				secondsmallest=arr[i];
			}
		}
		System.out.println("the second smallest element in an array: "+secondsmallest);
	}

}
