package array;

import java.util.Scanner;

public class SortingWithoutSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of an array: ");
		int n = sc.nextInt();
		System.out.println("Enter the array elements: ");
		int[] arr = new int[n];
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		sorted(arr);
	}

	private static void sorted(int[] arr) {
		// TODO Auto-generated method stub
int temp;
for (int i = 0, j = 1; i < arr.length - 1;) {
    if (j < arr.length) {
        if (arr[j] < arr[i]) {
            temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
        j++;
    } else {
        i++;
        j = i + 1;
    }
}
		
		System.out.println("after sorting: ");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
