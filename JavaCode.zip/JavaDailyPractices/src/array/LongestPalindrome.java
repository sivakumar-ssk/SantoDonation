package array;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Scanner;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.lang.Math;

public class LongestPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array size: ");
		int n = sc.nextInt();
		int arr[];
		arr=new int[n];
		System.out.println("Enter the array elements: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		int[] newarr= new int[n];
		for(int i=0;i<arr.length;i++) {
			int rem=0,rev=0,temp=0;
			temp = arr[i];
			while(temp!=0) {
				rem = temp%10;
				rev = (rev*10) + rem;
				temp = temp/10;
				
				if(arr[i]==rev) {
					newarr[i]=arr[i];
				}
			}	
		}
		//int largest = newarr[0];
		/*for(int i=0;i<newarr.length;i++) {
			System.out.print(newarr[i]+" ");
			if(newarr[i]>largest) {
				largest=newarr[i];
			}
		}*/
		Stream<Integer> strm = Arrays.stream(newarr).boxed();
		Optional<Integer> result=strm.max(Comparator.naturalOrder());
		int res = Arrays.stream(newarr).max().orElseThrow();
		System.out.println("\nThe longest palindrome in array: "+result+", "+res);
		
	}

}
