package array;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MainRemoveDups {
    public static void main(String[] args) {
        String originalString = "Hello, World!";
        String result = removeDuplicates(originalString);
        
        System.out.println("Original String: " + originalString);
        System.out.println("String without duplicates: " + result);
    }

    public static String removeDuplicates(String s) {
        StringBuilder sb = new StringBuilder();
        Set<Character> seen = new HashSet<>();
        char[] a = s.toCharArray();
      //  List<Character> l = new ArrayList<>();
       // List<char[]> l = Arrays.asList(a);
        Set<Character> set = new HashSet<>();
        for(char c: a) {
        	set.add(c);
        }
        System.out.println(set);
        for (char c : s.toCharArray()) {
            if (!seen.contains(c)) {
                seen.add(c);
                sb.append(c);
            }
        }
        //List<Character> strm = set.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        //Stream<Character> strm = seen.stream().sorted();
        //System.out.printf("printing list: ", strm);
        //System.out.println();
        return sb.toString();
    }
}
