package array;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class StrRev {

	public static void main(String[] args) {
		String s = "srijaa";
		
		char[] arr = s.toCharArray();
		int startingIndex = 0;
		int endIndex = arr.length - 1;
		
		while(startingIndex < endIndex) {
			char temp = arr[startingIndex];
			arr[startingIndex] = arr[endIndex];
			arr[endIndex] = temp;
			startingIndex++;
			endIndex--;
		}
		String reversed = new String(arr);
		System.out.println(reversed);
		String i = Arrays.toString(arr);
		System.out.println(i);
	}
}
//}
