package array;

import java.util.Arrays;
import java.util.Scanner;

public class Search {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the array size: ");
		int size = s.nextInt();
		int arr[];
		arr = new int[size];
		System.out.println("Enter the array: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=s.nextInt();
		}
		for(int i:arr) {
			System.out.print(i+" ");
		}
		System.out.println("\nEnter the element to be found: ");
		int d = s.nextInt();
		System.out.println();
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==d) {
				System.out.println("The element is found on: "+i);
				break;
			}
		}
	}

}
