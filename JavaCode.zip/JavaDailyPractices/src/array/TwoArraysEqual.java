package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class TwoArraysEqual {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size: ");
		int n = sc.nextInt();
		int arr[];
		arr=new int[n];
		int arr1[]=new int[n];
		System.out.println("Enter the elements of 1st array: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the elements of 2nd array: ");
		for(int i=0;i<arr1.length;i++) {
			arr1[i]=sc.nextInt();
		}
		Boolean result = Arrays.equals(arr, arr1);
		if(result==true) {
			System.out.println("both arrays are equal");
		}
		else {
			System.out.println("both arrays are not equal");
		}
	}

}
