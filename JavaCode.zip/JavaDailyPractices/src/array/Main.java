package array;

interface Animal {
	void sound();
}
interface PetAnimal {
	void sound();
}
class Dog implements Animal, PetAnimal{
	@Override
	public void sound(){
		System.out.println("zzz");
	}
}
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Animal a = new Dog();
			a.sound();
			PetAnimal p = new Dog();
			p.sound();
		}
	}


