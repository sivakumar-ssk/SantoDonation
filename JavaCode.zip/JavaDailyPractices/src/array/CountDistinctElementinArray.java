package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class CountDistinctElementinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] array = {12,21,35,35,45,54,54,65,12};
		List<Integer> a = new ArrayList<>();
		for(int i: array) {
			a.add(i);
		}
		System.out.println(a);
		int j=0,temp;
		for(int i=1;i<array.length;i++) {
			if(array[i]!=array[j]) {
				j=j+1;
				temp=array[i];
				array[i]=array[j];
				array[j]=temp;
			}
		}
		for(int i=0;i<j;i++) {
			System.out.println(array[i]);
		}
		/*System.out.println("Enter size of an array: ");
		int n = sc.nextInt();
		int[] arr;
		arr=new int[n];
		System.out.println("Enter the array elements: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		int count=0,index=0;
		int newarr[]=new int[n];
		for(int i=0;i<arr.length;i++) {
			int flag=0;
			for(int j=0; j<i;j++) {
				if(arr[i]==arr[j]&&i!=j) {
					flag=1;
					break;
				}
			}
				if(flag==0) {
					newarr[index]=arr[i];
					index++;
				}
		}
		for(int i=0;i<index;i++) {
			System.out.print(newarr[i]+" ");
		}
		System.out.println("\nThe count of distinct elements are: "+index);
		*/
	}
}
