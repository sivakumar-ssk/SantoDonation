package array;

import java.util.Arrays;
import java.util.Scanner;
import java.lang.Math;

public class SmallestLargest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size: ");
		int n = sc.nextInt();
		int[] arr;
		arr=new int[n];
		System.out.println("Enter the elements: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		int smallest=arr[0];
		int largest=arr[0];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>largest) 
				largest=arr[i];

			if(arr[i]<=smallest) 
				smallest=arr[i];
			
		}
		System.out.println("the largest element in the array: "+largest);
		System.out.println("the smallest element in the array: "+smallest);
	}

}
