package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class RepeatingElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter array size: ");
		int n=sc.nextInt();
		int[] arr;
		arr=new int[n];
		System.out.println("Enter array elements: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		int newarr[]=new int[n];
		List<int[]> c = new ArrayList<>();
		int k=0;
		System.out.println("the repeating elements are: ");
		for(int i=0;i<arr.length;i++) {
			int d=arr[i];
			if(!c.contains(d)) { 
				System.out.print(d+" ");
			for(int j=i+1;j<arr.length;j++) {
		
				if(arr[i]==arr[j])  {
					newarr[k]=arr[i];
				}
				} 
				k=k+1;
				
			}
		}
		//Arrays.
		c=Arrays.asList(newarr);
		System.out.println();
		for(int i=0;i<k;i++) {
			//if(newarr[i]!=0) {
			
			System.out.print(newarr[i]+" ");
			//}
		} 
	}
}
