package com.example.springwebstarter.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.example.springwebstarter.exception.BookNotFoundException;
import com.example.springwebstarter.exception.TokenExpireException;
import com.example.springwebstarter.model.ApiResponse;

@ControllerAdvice
public class MyControllerAdvice {

	@ExceptionHandler(BookNotFoundException.class)
	public ResponseEntity<ApiResponse> handleBookNotFoundException(BookNotFoundException e,WebRequest request){
		ApiResponse response = new ApiResponse(404,e.getMessage());
		return new ResponseEntity<ApiResponse>(response,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(TokenExpireException.class)
	public ResponseEntity<ApiResponse> handleTokenExpireException(TokenExpireException e,WebRequest request){
		ApiResponse response = new ApiResponse(404,e.getMessage());
		return new ResponseEntity<ApiResponse>(response,HttpStatus.NOT_FOUND);
	}
}
