package com.example.springwebstarter.exception;

public class TokenExpireException extends Exception {

	public TokenExpireException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
