package com.example.springwebstarter.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.example.springwebstarter.exception.BookNotFoundException;
import com.example.springwebstarter.exception.TokenExpireException;
import com.example.springwebstarter.model.Book;
import com.example.springwebstarter.service.BookService;

@RestController
public class BookController {

	@Autowired
	BookService service;
	
	
	@GetMapping(value="/book/{id}")
	public Book getBook(@PathVariable("id") int id ,@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws TokenExpireException, BookNotFoundException {
		return service.getBook(id,requestTokenHeader);
	}
	
	@GetMapping(value="/books")
	public List<Book> getBookAll(@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws TokenExpireException {
		return service.getBookAll(requestTokenHeader);
	}
	
	
}
