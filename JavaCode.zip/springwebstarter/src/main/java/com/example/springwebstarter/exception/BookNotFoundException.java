package com.example.springwebstarter.exception;

public class BookNotFoundException extends Exception {

	public BookNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
