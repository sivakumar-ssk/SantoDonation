package com.example.springwebstarter.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springwebstarter.clients.AuthClient;
import com.example.springwebstarter.exception.BookNotFoundException;
import com.example.springwebstarter.exception.TokenExpireException;
import com.example.springwebstarter.model.Book;
import com.example.springwebstarter.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
	AuthClient authClient;
	
	@Autowired
	BookRepository bookRepository;
	
	public Book getBook(int id,String requestTokenHeader) throws TokenExpireException, BookNotFoundException {
		Boolean result = authClient.authorizeTheRequest(requestTokenHeader);
		if(result==true) {
			Book book = bookRepository.findById(id).orElse(null);
			if(book != null ) {
				return book;
			}
			else {
				throw new BookNotFoundException("Book not Found");
			}
		}
		else {
			throw new TokenExpireException("Token is Invalid");
		}
		
	}
	
	public List<Book> getBookAll(String requestTokenHeader) throws TokenExpireException {
		Boolean result = authClient.authorizeTheRequest(requestTokenHeader);
		if(result==true) {
			return bookRepository.findAll();
		}
		else {
			throw new TokenExpireException("Token is Invalid");
		}
		
	}
}
