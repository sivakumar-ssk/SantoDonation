insert into book (id,name,price) values(1,'Book2',7000);
insert into book (id,name,price) values(2,'Book3',7000);
insert into book (id,name,price) values(3,'Book2',7000);
insert into book (id,name,price) values(4,'Book2',7000);