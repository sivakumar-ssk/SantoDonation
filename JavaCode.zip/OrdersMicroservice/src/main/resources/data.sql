insert into orders (order_Id, product_name, price) values(1, 'keychain', 50);
insert into orders (order_Id, product_name, price) values(2, 'babydoll', 200);
insert into orders (order_Id, product_name, price) values(3, 'car', 250);
insert into orders (order_Id, product_name, price) values(4, 'toytruck', 500);