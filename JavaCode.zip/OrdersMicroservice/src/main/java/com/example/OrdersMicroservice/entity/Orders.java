package com.example.OrdersMicroservice.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Orders {

	@Id
	@Column(name="order_Id")
	private int order_Id;
	private String product_name;
	private int price;
	
	public Orders(int order_id, String product_name, int price) {
		super();
		this.order_Id = order_id;
		this.product_name = product_name;
		this.price = price;
	}

	public Orders() {
		super();
	}

	public int getId() {
		return order_Id;
	}

	public void setId(int order_id) {
		this.order_Id = order_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
}
