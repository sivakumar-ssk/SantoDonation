package com.example.OrdersMicroservice.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.example.OrdersMicroservice.exception.OrderNotFoundException;
import com.example.OrdersMicroservice.model.ApiResponse;

@RestControllerAdvice
public class MyControllerAdvise{

		@ExceptionHandler(OrderNotFoundException.class)
		public ResponseEntity<ApiResponse> handleOrderNotFoundException(OrderNotFoundException e,WebRequest request){
			ApiResponse response = new ApiResponse(404,e.getMessage());
			return new ResponseEntity<ApiResponse>(response,HttpStatus.NOT_FOUND);
		}
	
 
}
