package com.example.OrdersMicroservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.OrdersMicroservice.entity.Orders;
import com.example.OrdersMicroservice.exception.OrderNotFoundException;
import com.example.OrdersMicroservice.service.OrderService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@GetMapping("/orders")
	public Page<Orders> getAllOrders(
			@RequestParam (defaultValue = "0") int page,
			@RequestParam (defaultValue = "1") int size) {
		Pageable pageable = PageRequest.of(page, size);
		return orderService.getAllOrders(pageable); 
	}
	/*@RequestMapping("/greet")
	public String greet() {
		return "welcome to orders homepage";
	}*/
	@GetMapping("/orders/{order_Id}")
	public Orders getOrderById(@PathVariable int order_Id) throws OrderNotFoundException{
		return orderService.getOrderById(order_Id);	
	}
	@PostMapping("/orders")
	public Orders createOrder(@RequestBody Orders orders) {
		return orderService.createOrder(orders);
	}
	//@PatchMapping
	
	
	@PutMapping("/orders/{order_Id}")
	public Orders updateOrder(@PathVariable int order_Id, @RequestParam String product_name, int price ) throws OrderNotFoundException {
		Orders order = orderService.updateOrder(order_Id, product_name, price);
		return order;
	}

	@DeleteMapping("/orders/{order_Id}")
	public void deleteOrderById(@PathVariable int order_Id) {
		orderService.deleteOrderById(order_Id);
	}
	
	@GetMapping("/csrf-token")
	public CsrfToken getCSRF(HttpServletRequest request) {
		return (CsrfToken) request.getAttribute("_csrf");
		
	}
}
