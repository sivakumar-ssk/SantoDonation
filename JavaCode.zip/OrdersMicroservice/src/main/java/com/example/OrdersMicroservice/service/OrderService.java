package com.example.OrdersMicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.OrdersMicroservice.entity.Orders;
import com.example.OrdersMicroservice.exception.OrderNotFoundException;
import com.example.OrdersMicroservice.repository.OrderRepository;


@Service
public class OrderService {
	
	@Autowired
	OrderRepository orderRepository;

	@Transactional
	public Page<Orders> getAllOrders(Pageable pageable) {
		// TODO Auto-generated method stub
		return orderRepository.findAll(pageable);
	}

	public Orders getOrderById(int order_Id) throws OrderNotFoundException{
		// TODO Auto-generated method stub
		Orders order = orderRepository.findById(order_Id).orElse(null);
		if(order == null ){
			throw new OrderNotFoundException("Order Id Was not found!");
		}
		return order;
	}

	public Orders createOrder(Orders orders) {
		// TODO Auto-generated method stub
		return orderRepository.save(orders);
	}
	
	@Transactional
	public Orders updateOrder(int order_Id,String product_name, int price) throws OrderNotFoundException {
		// TODO Auto-generated method stub
		Orders order = orderRepository.findById(order_Id).orElse(null);
		if(order != null) {
			//order.
			order.setProduct_name(product_name);
			order.setPrice(price);
			return orderRepository.save(order);
		}else {
			throw new OrderNotFoundException("Order Id Was not found!");
		}
		
	}

	public void deleteOrderById(int order_Id) {
		// TODO Auto-generated method stub
		 orderRepository.deleteById(order_Id);
	}

	
}
