package com.example.OrdersMicroservice.serviceTest;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.OrdersMicroservice.entity.Orders;
import com.example.OrdersMicroservice.exception.OrderNotFoundException;
import com.example.OrdersMicroservice.repository.OrderRepository;
import com.example.OrdersMicroservice.service.OrderService;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {
	
	@InjectMocks
	OrderService orderService;
	
	@Mock
	OrderRepository orderRepository;
	
	@Test
	void createOrderSuccessfully() {
		// TODO Auto-generated method stub
		Orders orders = new Orders();
		orders.setId(1);
		orders.setPrice(200);
		orders.setProduct_name("remote");
		Mockito.when(orderRepository.save(orders)).thenReturn(orders);
		Orders addedOrder = orderService.createOrder(orders);
		Assertions.assertEquals(orders, addedOrder);
	}
	
	@Test
	void getOrderByIdSuccessfully() throws OrderNotFoundException {
		Optional<Orders> orders = Optional.ofNullable(new Orders());
		Mockito.when(orderRepository.findById(1)).thenReturn(orders);
		Orders foundOrder = orderService.getOrderById(1);
		Assertions.assertEquals(orders, foundOrder);
	}
}
