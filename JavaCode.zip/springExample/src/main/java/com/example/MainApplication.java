package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.beans.Employee;
import com.example.beans.Project;

public class MainApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext act = new ClassPathXmlApplicationContext("config.xml");
		Employee emp1 = (Employee) act.getBean("emp1");
		System.out.println("EmployeeId"+"  "+"EmployeeName"+"  "+"Designation"+"  "+"EmployeeSalary"+
		"  "+"ProjectId"+"  "+"ProjectName");
		System.out.println(emp1.getEmployeeId()+"            "+emp1.getEmployeeName()+"         "+emp1.getDesignation()+"     "+
		emp1.getEmployeeSalary()+"           "+emp1.getProject().getProjectId()+"        "+emp1.getProject().getProjectName());
		
		Project proj1 = (Project) act.getBean("proj1");
		System.out.println("ProjectId"+"  "+"ProjectName"+"  "+"EmployeeId");
		System.out.println(proj1.getProjectId()+"       "+proj1.getProjectName()+"     "+proj1.getEmployee().getEmployeeId());
	}

}
