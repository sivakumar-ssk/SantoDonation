package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.beans.Employee;
import com.cts.dao.EmployeeDAO;

public class EmployeeService {
//	@Autowired
	private EmployeeDAO employeeDAO;

	
	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}


	public void createEmployee(Employee employee)
	{
		employeeDAO.createEmployee(employee);
	}
	
	public void showEmployee() {
		List<Employee> employeeList=employeeDAO.showEmployee();
		for(Employee  employee: employeeList)
		{
			System.out.printf("\n%5d %20s %5d",employee.getEmpId(),employee.getEmpName(),employee.getEmpSalary());
		
		}
	}
}
