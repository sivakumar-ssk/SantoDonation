package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.cts.beans.Employee;

public class EmployeeDAO {
//	@Autowired
	private JdbcTemplate jdbcTemplateObject;
	
	

	public void setJdbcTemplateObject(JdbcTemplate jdbcTemplateObject) {
		this.jdbcTemplateObject = jdbcTemplateObject;
	}



	public void createEmployee(Employee employee) {
		String query="INSERT INTO EMPLOYEE VALUE(?,?,?)";
		int result=jdbcTemplateObject.update(query, new Object[] {employee.getEmpId(),employee.getEmpName(),employee.getEmpSalary()});
		if(result>0)
		{
			System.out.println("Record Added!");
		}
		else {
			System.out.println("Record Not Added!!");
		}
	}
	public List<Employee> showEmployee() {
		String query="SELECT * FROM EMPLOYEE";
		List<Employee> employeeList=jdbcTemplateObject.query(query, new RowMapper<Employee>() {

			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				Employee employee=new Employee();
				employee.setEmpId(rs.getInt(1));
				employee.setEmpName(rs.getString(2));
				employee.setEmpSalary(rs.getInt(3));
				return employee;
			}
			
		});
		return employeeList;
	}
}
