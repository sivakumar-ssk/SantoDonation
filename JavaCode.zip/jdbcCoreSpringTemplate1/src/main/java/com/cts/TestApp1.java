package com.cts;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.beans.Employee;
import com.cts.dao.EmployeeDAO;
import com.cts.service.EmployeeService;

public class TestApp1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx= new ClassPathXmlApplicationContext("config.xml");
		EmployeeService employeeService=ctx.getBean(EmployeeService.class);
//		EmployeeDAO employeeDAO=ctx.getBean(EmployeeDAO.class);
		Employee employee=new Employee();
		employee.setEmpId(105);
		employee.setEmpName("Rituraj");
		employee.setEmpSalary(10000);
//		employeeDAO.createEmployee(employee);
		employeeService.createEmployee(employee);
	}
	
}
