package com.cts;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.service.EmployeeService;

public class TestApp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
		EmployeeService employeeService=ctx.getBean(EmployeeService.class);
		employeeService.showEmployee();
	}

}
