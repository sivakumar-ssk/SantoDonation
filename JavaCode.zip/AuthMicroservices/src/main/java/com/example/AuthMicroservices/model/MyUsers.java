package com.example.AuthMicroservices.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="MY_USERS")
public class MyUsers {
	@Id
	@Column(name="USER_ID")
	private Integer userId;
	private String role;
	private String password;
	public int getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public MyUsers(Integer userId, String role, String password) {
		super();
		this.userId = userId;
		this.role = role;
		this.password = password;
	}
	public MyUsers() {
		super();
	}
	@Override
	public String toString() {
		return "MyUsers [UserId=" + userId + ", role=" + role + ", password=" + password + "]";
	}
	
	
}
