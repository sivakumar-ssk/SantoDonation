package com.example.AuthMicroservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.AuthMicroservices.model.MyUsers;
import com.example.AuthMicroservices.service.AuthService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class AuthController {

	@Autowired
	AuthService authService;
	
	@RequestMapping("/")
	public String greet(HttpServletRequest request) {
		return "welcome to homepage"+ request.getSession().getId();
	}
	@GetMapping("/users")
	public List<MyUsers> getUsers() {
		return authService.getUsers();
		
	}
	@GetMapping("/csrf-token")
	public CSRFToken getCSRF(HttpServletRequest request) {
		return request.getAttribute("_csrf");
		
	}
}
