package com.example.AuthMicroservices.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.AuthMicroservices.model.MyUsers;
import com.example.AuthMicroservices.repository.MyUserRepository;

@Service
public class AuthService {
	
	@Autowired
	MyUserRepository myuserRepository;

	public List<MyUsers> getUsers() {
		// TODO Auto-generated method stub
		
		return myuserRepository.findAll();
	}

}
