
insert into MY_USERS (USER_ID, ROLE, PASSWORD) values(1, 'Admin', 'siva');
insert into MY_USERS (USER_ID, ROLE, PASSWORD) values(2, 'Developer', 'srijaa');